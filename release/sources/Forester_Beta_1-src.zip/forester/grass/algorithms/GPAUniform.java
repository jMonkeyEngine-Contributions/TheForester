/*
 * Copyright (c) 2011, Andreas Olofsson
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * Redistributions of source code must retain the above copyright notice, 
 * this list of conditions and the following disclaimer.
 * 
 * Redistributions in binary form must reproduce the above copyright notice, 
 * this list of conditions and the following disclaimer in the documentation 
 * and/or other materials provided with the distribution.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package forester.grass.algorithms;

import forester.grass.GrassPage;
import forester.image.DensityMap;
import forester.util.FastRandom;
import forester.RectBounds;

/**
 * The default planting algorithm.
 * 
 * @author Andreas
 */
public class GPAUniform implements GrassPlantingAlgorithm {

    @Override
    public int generateGrassData(   GrassPage page,
                                    DensityMap densityMap,
                                    float[] grassData,
                                    int grassCount) 
    {
        RectBounds bounds = page.getBounds();
        //Populating the array of locations (and also getting the total amount
        //of quads).
        FastRandom rand = new FastRandom();
        //These values are used to match generated xz-values with the density map.
        float xOff = page.getX() * bounds.getWidth();
        float zOff = page.getZ() * bounds.getHeight();
        //Iterator
        int iIt = 0;

        for (int i = 0; i < grassCount; i++) {
            float x = rand.unitRandom() * bounds.getWidth();
            float z = rand.unitRandom() * bounds.getHeight();

            if (rand.unitRandom() < densityMap.getDensityUnfiltered(x + xOff, z + zOff)) {
                grassData[iIt++] = x + bounds.getxMin();
                grassData[iIt++] = z + bounds.getzMin();
                grassData[iIt++] = rand.unitRandom();
                //-pi/2 -> pi/2
                grassData[iIt++] = (-0.5f + rand.unitRandom())*3.141593f;
            }
        }
        //The iterator divided by four is the grass-count.
        return iIt / 4;
    }
}//GPAUniform
