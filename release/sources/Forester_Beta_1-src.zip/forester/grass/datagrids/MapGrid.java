/*
 * Copyright (c) 2012, Andreas Olofsson
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * Redistributions of source code must retain the above copyright notice, 
 * this list of conditions and the following disclaimer.
 * 
 * Redistributions in binary form must reproduce the above copyright notice, 
 * this list of conditions and the following disclaimer in the documentation 
 * and/or other materials provided with the distribution.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package forester.grass.datagrids;

import com.jme3.math.ColorRGBA;
import com.jme3.texture.Texture;
import forester.grass.GrassTile;
import forester.image.ColorMap;
import forester.image.DensityMap;
import forester.image.FormatReader.Channel;
import grid.GenericCell2D;
import grid.Grid2D;
import java.util.HashMap;

/**
 * The mapgrid is used to store density/colormaps, and feeding them
 * to the grassloader.
 * 
 * @author Andreas
 */
public class MapGrid implements MapProvider {
    
    protected Grid2D<MapCell> grid;
    protected int tileSize;

    public MapGrid(int tileSize) {
        this.tileSize = tileSize;
        grid = new Grid2D<MapCell>();
    }
    
    @Override
    public MapBlock getMaps(GrassTile tile) {
        MapCell mapCell = grid.getCell(tile.getX(), tile.getZ());
        
        //Return null to set the page as being idle (no processing).
        if(mapCell == null || mapCell.densityMaps.isEmpty()){
            return null;
        }
        
        MapBlock block = new MapBlock();
        block.setDensityMaps(mapCell.densityMaps);
        if(mapCell.colorMaps != null){
            block.setColorMaps(mapCell.colorMaps);
        }
        
        return block;
    }
    
     
    
    /**
     * Adds a densitymap to the grid.
     * 
     * @param tex The texture to be used.
     * @param x The x-index (or coordinate) within the grid.
     * @param z The z-index within the grid.
     * @param flipX Flip the image X coords.
     * @param flipY Flip the image Y coords.
     */
    public void addDensityMap(Texture tex, int x, int z, int layer, boolean flipX, boolean flipY){
        loadMapCell(x,z).addDensityMap(tex,layer,flipX,flipY);
    }
    
    public void addDensityMap(Texture tex, int x, int z, int layer, boolean flipX, boolean flipY, Channel channel){
        loadMapCell(x,z).addDensityMap(tex, layer, flipX, flipY, channel);
    }
    
    public void addDensityMap(Texture tex, int x, int z, int layer){
        addDensityMap(tex,x,z,layer,false,false);
    }
    
    /**
     * Method to add a float array as a density map.
     * 
     * @param densityMap
     * @param x
     * @param z 
     */
    public void addDensityMap(float[] densityMap, int x, int z, int layer){
        loadMapCell(x,z).addDensityMap(densityMap,layer);
    }
    
    /**
     * Adds a colormap to the grid.
     * 
     * @param tex The texture to be used.
     * @param x The x-index (or coordinate) within the grid.
     * @param z The z-index within the grid.
     * @param flipX Flip the image X coords.
     * @param flipY Flip the image Y coords.
     */
    public void addColorMap(Texture tex, int x, int z, int layer,boolean flipX, boolean flipY){
        MapCell cell = grid.getCell(x,z);
        if(cell == null){
            throw new RuntimeException("Tried loading color map to empty cell: " + cell.toString());
        }
        cell.addColorMap(tex,layer,flipX,flipY);
    }
    
    public void addColorMap(Texture tex, int x, int z, int layer){
        addColorMap(tex,x,z,layer,false,false);
    }
    
    public void addColorMap(ColorRGBA[] colorMap, int x, int z, int layer){
        MapCell cell = grid.getCell(x,z);
        if(cell == null){
            throw new RuntimeException("Tried loading color map to empty cell: " + cell.toString());
        }
        cell.addColorMap(colorMap,layer);
    }
    
    /**
     * 
     * @param x The x-coordinate.
     * @param z The z-coordinate.
     * @return The mapcell.
     */
    public MapCell loadMapCell(int x, int z){
        MapCell mapCell = grid.getCell(x,z);
        if(mapCell == null){
            mapCell = new MapCell(x,z);
            grid.add(mapCell);
        }
        return mapCell;
    }
    
    /**
     * This class is used to store density and colormaps.
     */
    protected class MapCell extends GenericCell2D {
        
        public HashMap<Integer,DensityMap> densityMaps;
        public HashMap<Integer,ColorMap> colorMaps;
        
        protected MapCell(int x, int z){
            super(x,z);
            densityMaps = new HashMap<Integer,DensityMap>();
            colorMaps = new HashMap<Integer,ColorMap>();
        }
        
        protected void addDensityMap(Texture tex, int layer, boolean flipX, boolean flipY){
            DensityMap map = new DensityMap(tex,flipX,flipY);
            densityMaps.put(layer, map);
        }
        
        protected void addDensityMap(Texture tex, int layer, boolean flipX, boolean flipY, Channel channel){
            DensityMap map = new DensityMap(tex,channel,flipX,flipY);
            densityMaps.put(layer, map);
        }
        
        protected void addDensityMap(float[] densities, int layer){
            DensityMap map = new DensityMap(densities, tileSize);
            densityMaps.put(layer, map);
        }
        
        protected void addColorMap(Texture tex, int layer, boolean flipX, boolean flipY){
            ColorMap map = new ColorMap(tex, flipX, flipY);
            colorMaps.put(layer, map);
        }
        
        protected void addColorMap(ColorRGBA[] colors, int layer){
            ColorMap map = new ColorMap(colors, tileSize);
            colorMaps.put(layer, map);
        }

        @Override
        public boolean equals(Object obj) {
            if (obj == null) {
                return false;
            }
            if (getClass() != obj.getClass()) {
                return false;
            }
            final GenericCell2D other = (GenericCell2D) obj;
            if (this.hash != other.hashCode()) {
                return false;
            }
            return true;
        }
        
        @Override
        public int hashCode(){
            return hash;
        }
        
        @Override
        public String toString() {
            return "MapCell: (" + Short.toString(x) + ',' + Short.toString(z) + ')';
        }
        
    }//MapCell
    
}
