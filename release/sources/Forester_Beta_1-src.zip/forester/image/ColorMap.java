/*
 * Copyright (c) 2011, Andreas Olofsson
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * Redistributions of source code must retain the above copyright notice, 
 * this list of conditions and the following disclaimer.
 * 
 * Redistributions in binary form must reproduce the above copyright notice, 
 * this list of conditions and the following disclaimer in the documentation 
 * and/or other materials provided with the distribution.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package forester.image;

import com.jme3.math.ColorRGBA;
import com.jme3.texture.Texture;

/**
 * This class is used with the GrassGrid to color grass meshes.
 * It borrows from the terrain height map system.
 * 
 * @author Andreas
 */
public class ColorMap extends ForesterMap {

    private ColorRGBA[] colors = null;
    
    /**
     * Create a color map based on a texture.
     * 
     * @param tex The texture.
     * @param flipX
     * @param flipY 
     */
    public ColorMap(Texture tex, boolean flipX, boolean flipY){
        super(tex,flipX,flipY);
        load();
    }
    
    /**
     * Create a color map from an array of ColorRGBA values.
     * 
     * @param colors The array.
     * @param size The size of the map.
     */
    public ColorMap(ColorRGBA[] colors, int size){
        this.colors = colors;
        this.size = size;
    }
    
    /**
     * Fetches a ColorRGBA value from the given indices.
     * 
     * @param x The x-coordinate of the texel.
     * @param z The z-coordinate of the texel. Using the name 
     * z since its used by default in the grids.
     * @return The colorvalue.
     */
    public ColorRGBA getColorUnfiltered(float x, float z) {
        //Get integer part
        int xIndex = (int) x;
        int zIndex = (int) z;
        //Clamp
        xIndex = (xIndex < 0) ? 0 : (xIndex > size - 1) ? size - 1: xIndex;
        zIndex = (zIndex < 0) ? 0 : (zIndex > size - 1) ? size - 1: zIndex;
        //Get the value
        return colors[xIndex + size*zIndex];
    }
    
    //TODO Make this effective before implementing...
    public ColorRGBA getColorBilinear(float x, float z){
        int xx = (int) Math.floor(x);
        int zz = (int) Math.floor(z);
        //Weights
        float wb = z - zz;
        float wr = x - xx;
        float wt = 1f - wb;
        float wl = 1f - wr;
        //Apply
        ColorRGBA color1 = getColorUnfiltered(xx,zz).multLocal(wl).addLocal(getColorUnfiltered(xx + 1,zz).multLocal(wr));
        ColorRGBA color2 = getColorUnfiltered(xx,zz + 1).multLocal(wl).addLocal(getColorUnfiltered(xx + 1, zz + 1).multLocal(wr));
        ColorRGBA finalColor = color1.multLocal(wt).addLocal(color2.multLocal(wb));
        finalColor.a = 1.0f;
        return finalColor;
    }
    
    @Override
    protected final void load() {
        size = reader.imageWidth;
        colors = new ColorRGBA[(size * size)];
        
        int index = 0;
        if (flipY) {
            for (int h = 0; h < size; ++h) {
                if (flipX) {
                    for (int w = size - 1; w >= 0; --w) {
                        colors[index++] = reader.getColor(w,h);
                    }
                } else {
                    for (int w = 0; w < size; ++w) {
                        colors[index++] = reader.getColor(w,h);
                    }
                }
            }
        } else {
            for (int h = size - 1; h >= 0; --h) {
                if (flipX) {
                    for (int w = size - 1; w >= 0; --w) {
                        colors[index++] = reader.getColor(w,h);
                    }
                } else {
                    for (int w = 0; w < size; ++w) {
                        colors[index++] = reader.getColor(w,h);
                    }
                }
            }
        }
    }
    
}//ColorMap
