/*
 * Copyright (c) 2011, Andreas Olofsson
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * Redistributions of source code must retain the above copyright notice, 
 * this list of conditions and the following disclaimer.
 * 
 * Redistributions in binary form must reproduce the above copyright notice, 
 * this list of conditions and the following disclaimer in the documentation 
 * and/or other materials provided with the distribution.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package forester.image;

import com.jme3.texture.Texture;
import forester.image.FormatReader.Channel;

/**
 * This class contains density map data. It borrows from the terrain height
 * map system.
 * 
 * @author Andreas
 */
public class DensityMap extends ForesterMap{
    
    protected float[] densities = null;
    
    /**
     * Create a density map based on a texture. The luminance values of the
     * pixels will be used as densities [0,1].
     * 
     * @param tex The texture.
     * @param flipX
     * @param flipY 
     */
    public DensityMap(Texture tex, boolean flipX, boolean flipY){
        super(tex,flipX,flipY);
        load();
    }
    
    /**
     * Create a density map based on a texture and the specified channel. The
     * color values will be used as densities [0,1].
     * 
     * @param tex The texture.
     * @param channel The channel (r/g/b/a).
     * @param flipX
     * @param flipY 
     */
    public DensityMap(Texture tex, Channel channel,boolean flipX, boolean flipY){
        super(tex,flipX,flipY);
        load(channel);
    }
    
    /**
     * Create a density map based on a float array. The array will be used
     * directly.
     * 
     * @param densities The float array containing the density values.
     * @param size 
     */
    public DensityMap(float[] densities, int size){
        this.densities = densities;
        this.size = size;
    }
    
    /**
     * A method to get density values.
     * 
     * @param x The x-coordinate of the texel.
     * @param z The z-coordinate of the texel. Using the name 
     * z since its used by default in the grids.
     * @return The density value.
     */
    public float getDensityUnfiltered(float x, float z) {
        int xIndex = (int) x;
        int zIndex = (int) z;
        //Clamp
        xIndex = (xIndex < 0) ? 0 : (xIndex > size - 1) ? size - 1: xIndex;
        zIndex = (zIndex < 0) ? 0 : (zIndex > size - 1) ? size - 1: zIndex;
        
        return densities[xIndex + size*zIndex];
    }
    
    public float getDensityBilinear(float x, float z){
        return 0;
    }
    
    @Override
    protected final void load() {
        size = reader.imageWidth;
        densities = new float[(size * size)];
        
        int index = 0;
        if (flipY) {
            for (int h = 0; h < size; ++h) {
                if (flipX) {
                    for (int w = size - 1; w >= 0; --w) {
                        densities[index++] = reader.getLuminance(w,h);
                    }
                } else {
                    for (int w = 0; w < size; ++w) {
                        densities[index++] = reader.getLuminance(w,h);
                    }
                }
            }
        } else {
            for (int h = size - 1; h >= 0; --h) {
                if (flipX) {
                    for (int w = size - 1; w >= 0; --w) {
                        densities[index++] = reader.getLuminance(w,h);
                    }
                } else {
                    for (int w = 0; w < size; ++w) {
                        densities[index++] = reader.getLuminance(w,h);
                    }
                }
            }
        }
    }
    
    protected final void load(Channel channel){
        size = reader.imageWidth;
        densities = new float[(size * size)];
        
        int index = 0;
        if (flipY) {
            for (int h = 0; h < size; ++h) {
                if (flipX) {
                    for (int w = size - 1; w >= 0; --w) {
                        densities[index++] = reader.getColor(w,h,channel);
                    }
                } else {
                    for (int w = 0; w < size; ++w) {
                        densities[index++] = reader.getColor(w,h,channel);
                    }
                }
            }
        } else {
            for (int h = size - 1; h >= 0; --h) {
                if (flipX) {
                    for (int w = size - 1; w >= 0; --w) {
                        densities[index++] = reader.getColor(w,h,channel);
                    }
                } else {
                    for (int w = 0; w < size; ++w) {
                        densities[index++] = reader.getColor(w,h,channel);
                    }
                }
            }
        }
    }
    
}//DensityMap
