/*
 * Copyright (c) 2011, Andreas Olofsson
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * Redistributions of source code must retain the above copyright notice, 
 * this list of conditions and the following disclaimer.
 * 
 * Redistributions in binary form must reproduce the above copyright notice, 
 * this list of conditions and the following disclaimer in the documentation 
 * and/or other materials provided with the distribution.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package forester.trees;

import com.jme3.bullet.control.RigidBodyControl;
import com.jme3.math.Quaternion;
import com.jme3.math.Vector3f;
import com.jme3.renderer.Camera;
import com.jme3.scene.Geometry;
import com.jme3.scene.Node;
import com.jme3.scene.Spatial;
import com.jme3.terrain.Terrain;
import forester.Forester;
import forester.trees.datagrids.DataGrid;
import forester.trees.datagrids.DataProvider;
import forester.trees.datagrids.UDTreeProvider;
import java.util.ArrayList;
import java.util.concurrent.Callable;
import paging.GeometryTileLoader;
import paging.interfaces.Page;
import paging.interfaces.Tile;

/**
 * This class is used to load trees.
 * 
 * @author Andreas
 */
public class TreeLoader extends GeometryTileLoader {

    protected ArrayList<TreeLayer> layers;
    protected TreeGeometryGenerator treeGen;
    protected TreeImpostorGenerator treeImpGen;
    protected DataProvider dataProvider;
    protected int nIt = Short.MAX_VALUE;

    public TreeLoader(int tileSize,
            int resolution,
            float viewingRange,
            float fadingRange,
            float transitioningDistance,
            Node rootNode,
            Terrain terrain,
            Camera camera) {
        super(tileSize, resolution, viewingRange, rootNode, terrain, camera);
        layers = new ArrayList<TreeLayer>();
        //TODO update here when impostors are finished.
        pagingEngine.addDetailLevel(viewingRange, fadingRange);
        treeGen = new TreeGeometryGenerator();
        init();
    }

    protected final void init() {
        pagingEngine.setTileLoader(this);
    }

    public TreeLayer addTreeLayer(Spatial model) {
        return addTreeLayer(model, true, false);
    }

    public TreeLayer addTreeLayer(Spatial model, boolean useBatching, boolean usePhysics) {
        TreeLayer layer = new TreeLayer(model, useBatching, usePhysics);
        layer.setName("TreeLayer" + nIt++);
        layers.add(layer);
        return layer;
    }

    @Override
    public TreeTile createTile(int x, int z) {
        return new TreeTile(x, z, pagingEngine);
    }

    @Override
    public Callable<Boolean> loadTile(Tile tile) {
        TreeTile tTile = (TreeTile) tile;
        LoadTask task = new LoadTask(tTile);
        return task;
    }

    public DataProvider getDataProvider() {
        return dataProvider;
    }

    public DataGrid createDataGrid() {
        DataGrid grid = new DataGrid(pagingEngine.getTileSize(), pagingEngine.getResolution());
        this.dataProvider = grid;
        return grid;
    }

    public UDTreeProvider createUDProvider(float density) {
        UDTreeProvider provider = new UDTreeProvider(density, this);
        this.dataProvider = provider;
        return provider;
    }

    public void setDataProvider(DataProvider dataProvider) {
        this.dataProvider = dataProvider;
    }

    public ArrayList<TreeLayer> getLayers() {
        return layers;
    }

    private class LoadTask implements Callable<Boolean> {

        private TreeTile tile;

        private LoadTask(TreeTile tile) {
            this.tile = tile;
        }

        @Override
        public Boolean call() {
            tile.createPages();
            TreeDataBlock block = dataProvider.getData(tile);
            if (block == null || block.isEmpty()) {
                return false;
            }

            float ps = pagingEngine.getPageSize() * 0.5f;
            
            for (int j = 0; j < tile.getPages().size(); j++) {
                TreePage page = (TreePage) tile.getPage(j);

                Node[] nodes = new Node[1];
                Node batchNode = new Node("BatchNode_" + tile.toString());
                
                for (TreeLayer layer : layers) {
                    ArrayList<TreeDataList> grid = block.get(layer);
                    if (grid == null || grid.isEmpty()) {
                        continue;
                    }
                    TreeDataList dataList = grid.get(j);
                    //Prepare a node for geometry batches.
                    Node model = layer.getModel();
                    if (layer.isUseBatching()) {
                        //Generate batches for each of the models geometries.
                        for (Spatial spat : model.getChildren()) {
                            Geometry baseGeom = (Geometry) spat;
                            Geometry staticGeometry = treeGen.generateStaticGeometry(baseGeom, dataList, false);
                            if (staticGeometry != null) {
                                page.getNode(0).attachChild(staticGeometry);
                            }
                        }
                    } else {
                        for (int i = 0; i < dataList.size(); i++) {
                            TreeData data = dataList.get(i);
                            Node m = model.clone(true);
                            for (Spatial spat : m.getChildren()) {
                                Geometry geom = (Geometry) spat;
                                RigidBodyControl control = geom.getControl(RigidBodyControl.class);
                                if (control != null) {
                                    control.setEnabled(false);
                                }
                                geom.setLocalTranslation(data.x, data.y, data.z);
                                geom.setLocalRotation(new Quaternion().fromAngleNormalAxis(data.rot, Vector3f.UNIT_Y));
                                geom.scale(data.scale);
                                batchNode.attachChild(geom);
                            }
                        }
                    }
                } //For each layer
                //Finalize
                nodes[0] = batchNode;
                page.setNodes(nodes);
                page.calculateOverlap(ps, 0);
                if(Forester.getInstance().getPhysicsSpace() != null){
                    page.initPhysics();
                }
            }//for each layer

            return true;
        }
    }//LoadTask
}//TreeLoader
