/*
 * Copyright (c) 2011, Andreas Olofsson
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * Redistributions of source code must retain the above copyright notice, 
 * this list of conditions and the following disclaimer.
 * 
 * Redistributions in binary form must reproduce the above copyright notice, 
 * this list of conditions and the following disclaimer in the documentation 
 * and/or other materials provided with the distribution.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package forester.trees;

import com.jme3.bounding.BoundingSphere;
import com.jme3.bullet.collision.shapes.CollisionShape;
import com.jme3.bullet.control.RigidBodyControl;
import com.jme3.scene.Geometry;
import com.jme3.scene.Mesh;
import com.jme3.scene.Node;
import com.jme3.scene.Spatial;
import com.jme3.texture.Texture;
import forester.Forester;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Class for storing different tree types.
 * 
 * @author Andreas
 */
public class TreeLayer {

    protected static final Logger log = Logger.getLogger(TreeLayer.class.getName());
    protected String name;
    protected Node model;
    protected CollisionShape collisionShape;
    protected boolean usePhysics;
    protected boolean useBatching;
    protected float minimumScale = 0.8f;
    protected float maximumScale = 1.2f;
    static protected String impostorTextureDir = "./";
    protected Texture impostorTexture;

    public TreeLayer(Spatial model, boolean useBatching, boolean usePhysics) {
        this.model = (Node) model.clone(true);
        this.useBatching = useBatching;
        this.usePhysics = usePhysics;
        if(useBatching && usePhysics){
            log.log(Level.SEVERE,"Physics has not yet been enabled for batched geometries.");
        }
        prepareModel();
    }

    //Set bounding spheres and prepare physics.
    protected final void prepareModel() {

        if (useBatching) {
            for (int i = 0; i < model.getChildren().size(); i++) {
                Geometry geom = (Geometry) model.getChild(i);
                Mesh mesh = geom.getMesh();
                mesh.setBound(new BoundingSphere());
                mesh.updateBound();
                geom.updateGeometricState();
            }
            model.updateGeometricState();
        }
        if (usePhysics) {
            if (!Forester.getInstance().isPhysicsEnabled()) {
                log.log(Level.SEVERE, "physics space not found. Physics disabled.");
                usePhysics = false;
                return;
            }
            RigidBodyControl control = model.getControl(RigidBodyControl.class);
            control.setEnabled(false);
//            collisionShape = control.getCollisionShape();
//            if (collisionShape == null) {
//                if (usePhysics == true) {
//                    log.log(Level.SEVERE, "Tree physics flagged as enabled, but no "
//                            + "RigidBodyControl was supplied with the model. Physics "
//                            + "has been disabled for model: {0}", model.toString());
//                    usePhysics = false;
//                }
//            }
        }
    }

    public Node getModel() {
        return model;
    }

    public CollisionShape getCollisionShape() {
        return collisionShape;
    }

    public void setMaximumScale(float maxScale) {
        maximumScale = maxScale;
    }

    public float getMaximumScale() {
        return maximumScale;
    }

    public void setMinimumScale(float minScale) {
        minimumScale = minScale;
    }

    public float getMinimumScale() {
        return minimumScale;
    }

    public boolean isUseBatching() {
        return useBatching;
    }

    public void setUseBatching(boolean useBatching) {
        this.useBatching = useBatching;
    }

    public boolean isUsePhysics() {
        return usePhysics;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final TreeLayer other = (TreeLayer) obj;
        if ((this.name == null) ? (other.name != null) : !this.name.equals(other.name)) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 37 * hash + (this.name != null ? this.name.hashCode() : 0);
        return hash;
    }
}//TreeLayer
