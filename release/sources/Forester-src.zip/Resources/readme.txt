From the original pg engine:

This grass texture included with PagedGeometry was kindly provided by
Agnisola Philippe (http://www.blitz3dfr.com/portal_joomla/) for 
commercial or non-commercial use.