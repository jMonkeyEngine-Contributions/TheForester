/*
 * Copyright (c) 2011, Andreas Olofsson
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * Redistributions of source code must retain the above copyright notice, 
 * this list of conditions and the following disclaimer.
 * 
 * Redistributions in binary form must reproduce the above copyright notice, 
 * this list of conditions and the following disclaimer in the documentation 
 * and/or other materials provided with the distribution.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package grid;

/**
 * A lightweight container for three integer coordinates. These objects are 
 * the elements of Grid3D.
 * 
 * @author Andreas
 */
public class GenericCell3D implements Cell3D{
    private final short x, y, z;
    private final int hash;
    
    /**
     * Create a cell with coordinates x, y and z.
     * 
     * @param x The x-coordinate of the cell.
     * @param y The y-coordinate of the cell.
     * @param z The z-coordinate of the cell.
     */
    public GenericCell3D(int x, int y, int z)
    {
        this.x = (short) x;
        this.y = (short) y;
        this.z = (short) z;
        hash = Grid3D.hash(x,y,z);
    }
    
    /**
     * Create a cell with the same coordinates as another cell.
     * 
     * @param xyz The cell to duplicate
     */
    public GenericCell3D(Cell3D xyz){
        this.x = xyz.getX();
        this.y = xyz.getY();
        this.z = xyz.getZ();
        this.hash = xyz.hashCode();
    }

    @Override
    public short getX() {
        return x;
    }
    
    @Override
    public short getY(){
        return y;
    }

    @Override
    public short getZ() {
        return z;
    }
    
    @Override
    public String toString() {
        return '(' + Short.toString(x) + ',' + Short.toString(y) 
                + ',' + Short.toString(z) + ')';
    }

    @Override
    public int hashCode() {
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final GenericCell3D other = (GenericCell3D) obj;
        if (this.hash != other.hash) {
            return false;
        }
        return true;
    }
    
}//GenericCell3D
