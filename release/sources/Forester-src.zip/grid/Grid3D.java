/*
 * Copyright (c) 2011, Andreas Olofsson
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * Redistributions of source code must retain the above copyright notice, 
 * this list of conditions and the following disclaimer.
 * 
 * Redistributions in binary form must reproduce the above copyright notice, 
 * this list of conditions and the following disclaimer in the documentation 
 * and/or other materials provided with the distribution.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package grid;

import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * This class is a container for Cell3D. It is based on ArrayList, but has
 * additional methods to lookup elements (cells) based on hashcodes.
 * <br/>
 * It also implements Cell3D which makes it possible to make a grid of
 * grids.
 * 
 * @author Andreas
 */
public class Grid3D extends ArrayList<Cell3D> implements Cell3D{
    
    protected static final Logger log = Logger.getLogger(Grid3D.class.getCanonicalName());
    
    //Cell data
    protected final short x,y,z;
    protected final int hash;
    
    //Hash data
    protected static byte p2 = 9;
    protected static short hashRadius = (1 << 9);
    protected static int maxCells = (1 << 30);
    
    protected static byte instances = 0;
    
    /**
     * Creates a grid at position 0,0,0 with x, y and z dimensions all 3 
     * (the initial array size is 27).
     */
    public Grid3D(){
        this(3,3,3,0,0,0);
    }
    
    /**
     * Creates a grid with size sizeX*sizeY*sizeZ at position 0,0,0.
     * 
     * @param sizeX The x-size of the grid.
     * @param sizeY The y-size of the grid.
     * @param sizeZ The z-size of the grid.
     */
    public Grid3D(int sizeX, int sizeY, int sizeZ){
        this(sizeX,sizeY,sizeZ,0,0,0);
    }
    
    /**
     * Creates a grid with size sizeX*sizeY*sizeZ at position x,y,z.
     * 
     * @param sizeX The x-size of the grid.
     * @param sizeY The y-size of the grid.
     * @param sizeZ The z-size of the grid.
     * @param x The x-position of the grid.
     * @param y The y-position of the grid.
     * @param z The z-position of the grid.
     */
    public Grid3D(int sizeX, int sizeY, int sizeZ, int x, int y, int z){
        super(sizeX*sizeY*sizeZ);
        this.x = (short) x;
        this.y = (short) y;
        this.z = (short) z;
        this.hash = hash(x,y,z);
        if(sizeX > hashRadius - 1 || sizeY > hashRadius - 1 || sizeZ > hashRadius - 1){
            throw new RuntimeException("The grid dimensions exceeds the maximum recommended values.");
        }
        instances++;
    }
    
    /**
     * Replaces the cell at the specified coords with the cell newCell, and 
     * returns the old cell. If no cell exists at the specified coords or if 
     * it is the same cell as newCell, the method returns null.
     * 
     * @param x The x-coordinate of the cell.
     * @param y The y-coordinate of the cell.
     * @param z The z-coordinate of the cell.
     * @param newCell The new cell.
     * @return The cell currently at position (x,y,z), or null.
     */
    public Cell3D setCell(short x, short y, short z, Cell3D newCell){
        return setCell(hash(x,y,z),newCell);
    }
    
    /**
     * Replaces the cell oldCell with the cell newCell. If no cell exists 
     * at the specified coords or if it is the same cell as newCell, the
     * method returns null.
     * 
     * @param oldCell The old cell.
     * @param newCell The new cell.
     * @return The cell oldCell, or null.
     */
    public Cell3D setCell(Cell3D oldCell, Cell3D newCell){
        return setCell(oldCell.hashCode(),newCell);
    }
    
    /**
     * Replaces the cell using the hashcode "hash" with the cell newCell, 
     * and returns the old cell. If no cell with hashcode "hash" exists or 
     * if it is the same cell as newCell, the method returns null.
     * 
     * @param hash The hash of the current cell.
     * @param newCell The new cell.
     * @return The gridcell with hashcode "hash", or null.
     */
    public Cell3D setCell(int hash, Cell3D newCell){
        int newHash = newCell.hashCode();
        if(hash == newHash){
            return null;
        }
        //Returns the old cell.
        Cell3D c = null;
        for(int i = 0; i < size(); i++){
            c = get(i);
            if(c.hashCode() == hash){
                return set(i,newCell);
            }
        }
        return null;
    }
    
    /**
     * Gets the cell at position x,y,z.
     * 
     * @param x The x-coordinate of the cell.
     * @param y The y-coordinate of the cell.
     * @param z The z-coordinate of the cell.
     * @return The cell at (x,y,z), or null if no such cell exists.
     */
    public Cell3D getCell(short x, short y, short z){
        return getCell(hash(x,y,z));
    }
    
    /**
     * Gets the cell with hashcode "hash".
     * 
     * @param hash the hashcode to use for lookup.
     * @return The cell with hashCode "hash", or null if no such cell exists.
     */
    public Cell3D getCell(int hash){
        Cell3D c = null;
        for(int i = 0; i < size(); i++){
            c = get(i);
            if(c.hashCode() == hash){
                return c;
            }
        }
        return null;
    }
    
    /**
     * Removes the cell with the given coordinates if its in the grid.
     * 
     * @param x The x-coordinate of the cell.
     * @param y The y-coordinate of the cell.
     * @param z The z-coordinate of the cell.
     * @return The cell, or null if it's not in the grid.
     */
    public Cell3D removeCell(int x, int y, int z){
        int hashCode = hash(x,y,z);
        Cell3D c = null;
        for(int i = 0; i < size(); i++){
            c = get(i);
            if(c.hashCode() == hashCode){
                return remove(i);
            }
        }
        return null;
    }
    
    /**
     * Removes a cell if its in the grid.
     * 
     * @param cell The cell to be removed.
     * @return The cell, or null if it's not in the grid.
     */
    public Cell3D removeCell(Cell3D cell){
        int hashCode = cell.hashCode();
        Cell3D c = null;
        for(int i = 0; i < size(); i++){
            c = get(i);
            if(c.hashCode() == hashCode){
                return remove(i);
            }
        }
        return null;
    }
    
    /**
     * Removes the cell with the given hashcode if its in the grid.
     * 
     * @param hash The hashcode of the cell.
     * @return The cell, or null if it's not in the grid.
     */
    public Cell3D removeCell(int hash){
        Cell3D c = null;
        for(int i = 0; i < size(); i++){
            c = get(i);
            if(c.hashCode() == hash){
                return remove(i);
            }
        }
        return null;
    }
    
    @Override
    public short getX() {
        return x;
    }

    @Override
    public short getY() {
        return y;
    }

    @Override
    public short getZ() {
        return z;
    }
    
    /**
     * Get the maximum number of cells the grid may contain.
     * 
     * @return The maximum number of gridcells.
     */
    public static int getMaxCells(){
        return maxCells;
    }
    
    /**
     * This method changes the "hash radius". The hash radius defaults to
     * 2^9, and is not to be exceeded. If you are planning on using a
     * small grid, you can use a lower value to speed it up.
     * <br/>
     * NOTE! This method can't be called after Grid3D has been instantiated.
     * 
     * @param powerOfTwo the power of two used in the radius.
     * (if you want to have a radius of 2^8, use powerOfTwo = 8)
     */
    public static void setHashRadius(int powerOfTwo){
        if(instances > 0){
            log.log(Level.INFO, "Grid3D has already been instantiated; gridRadius will not be changed.");
            return;
        } 
        if(powerOfTwo < 0 || powerOfTwo > 9){
            log.log(Level.INFO, "powerOfTwo must satisfy 0 < PoT < 9; gridRadius will not be changed.");
            return;
        }
        p2 = (byte) powerOfTwo;
        hashRadius = (short)(1 << powerOfTwo);
        maxCells = 1 << 3*(powerOfTwo+1);
    }
    /**
     * This method generates a 3*(p2 + 1) bit hashnumber for each triple of 
     * integers. The first (p2 + 1) bits are used for x, the next for y, etc.
     * The hash is unique assuming x, y and z are all contained in the interval
     * [-hashRadius,hashRadius - 1].
     * 
     * @param x the x-coordinate of the cell
     * @param y the y-coordinate of the cell 
     * @param z the z-coordinate of the cell
     */
    public static int hash(int x, int y, int z){
        return x + hashRadius + ((y + hashRadius) << p2 << 1) +
                        ((z + hashRadius) << ((p2 << 1) << 1));
    }
    
}//grid3D
