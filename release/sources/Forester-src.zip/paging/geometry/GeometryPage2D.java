/*
 * Copyright (c) 2011, Andreas Olofsson
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * Redistributions of source code must retain the above copyright notice, 
 * this list of conditions and the following disclaimer.
 * 
 * Redistributions in binary form must reproduce the above copyright notice, 
 * this list of conditions and the following disclaimer in the documentation 
 * and/or other materials provided with the distribution.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package paging.geometry;

import com.jme3.math.Vector3f;
import grid.Cell2D;

/**
 * This is a concrete implementation of the GeometryPage interface.
 * 
 * @author Andreas
 */
public class GeometryPage2D extends AbstractGeometryPage {
    
    /**
     * Constructor based on x and z coordinates.
     * 
     * @param x The x-coordinate of the page.
     * @param z The z-coordinate of the page.
     * @param engine The paging engine to be used with this page(type).
     */
    public GeometryPage2D(int x, int z, GeometryPagingEngine engine){
        super(x,z,engine);
    }
    
    /**
     * Constructor based on a Cell2D object.
     * 
     * @param xz The cell whos coordinates will be used.
     * @param engine The paging engine to be used with this page(type).
     */
    protected GeometryPage2D(Cell2D xz, GeometryPagingEngine engine){
        this(xz.getX(),xz.getZ(),engine);
    }
    
    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final GeometryPage2D other = (GeometryPage2D) obj;
        if (this.hash != other.hash) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        return hash;
    }
    
    /**
     * This nested class can be used if the boundary of the page is needed.
     */
    public class PageBounds2D {
        public float xMin, xMax, zMin, zMax;
        public float width,height;
        public Vector3f center;

        public PageBounds2D(float xMin, float zMin, float xMax, float zMax, Vector3f center) {
            this.xMin = xMin;
            this.xMax = xMax;
            this.zMin = zMin;
            this.zMax = zMax;
            width = xMax-xMin;
            height = zMax-zMin;
            this.center = center;
        }
    
        public PageBounds2D(Vector3f center, float pageSize){
            float hP = pageSize/2f;
            this.center = center;
            this.xMin = center.x - hP;
            this.xMax = center.x + hP;
            this.zMin = center.z - hP;
            this.zMax = center.z + hP;
            width = height = pageSize;
        }
    }//PageBounds2D
}//GeometryPage2D
