/*
 * Copyright (c) 2011, Andreas Olofsson
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * Redistributions of source code must retain the above copyright notice, 
 * this list of conditions and the following disclaimer.
 * 
 * Redistributions in binary form must reproduce the above copyright notice, 
 * this list of conditions and the following disclaimer in the documentation 
 * and/or other materials provided with the distribution.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package paging.geometry;

import com.jme3.math.FastMath;
import com.jme3.renderer.Camera;
import com.jme3.scene.Node;
import java.util.ArrayList;
import paging.AbstractPagingEngine;
import paging.Page;

/**
 * This is a concrete implementation of the GeometryPagingEngine.
 * 
 * @author Andreas
 */
public class GeometryPagingEngine2D extends AbstractPagingEngine implements GeometryPagingEngine{
    
    private Node pagingNode;
    private Node rootNode;
    private float farViewingDistance;
    //Used to turn visibility off globally.
    private boolean visible = true;
    
    private ArrayList<DetailLevel> detailLevels;
    private int numDetailLevels;
    private boolean usesFading = false;
    
    /**
     * Constructor.
     * 
     * @param pageSize The size of the pages (in world units).
     * @param farViewingDistance Used to determine the number of pages in the grid.
     * @param rootNode The root node of the scene associated with the paging engine.
     * @param camera A jME <code>Camera</code> object. Most grid-calculations are based 
     * on it.
     */
    public GeometryPagingEngine2D(  float pageSize,
                                    float farViewingDistance,
                                    Node rootNode,
                                    Camera camera
                                 )
    {
        super(pageSize,farViewingDistance,camera);
        this.rootNode = rootNode;
        this.farViewingDistance = farViewingDistance;
        detailLevels = new ArrayList<DetailLevel>();
        pagingNode = new Node("Paging");
        rootNode.attachChild(pagingNode);
    }

    @Override
    protected short calculateGridSize(float radius, float pageSize) {
        int pageBufferSize = (usesFading) ? 2: 1;
        return (short)(2*(FastMath.ceil(farViewingDistance/pageSize) + pageBufferSize) + 1);
    }

    @Override
    public void processPage(Page page){
        processPage((GeometryPage)page);
    }
    
    public void processPage(GeometryPage page) {
        //**************Visibility and fading calculations**************
            
        //If the pagingNode is hidden, don't make any visibility
        //calculations.
        if (!isVisible()){
           return;
        }
            
        //Get the distance to the page center.
        float dx = page.getCenterPoint().x - camPos.x;
        float dz = page.getCenterPoint().z - camPos.z;
        float distSq = dx*dx + dz*dz;
            
        //Pointer
        Node node = null;
            
        //Start with the detail-level furthest away
        for(int l = detailLevels.size() - 1;l >= 0; l--){
                
            DetailLevel thisLvl = detailLevels.get(l);
            DetailLevel nextLvl = null;
                
            if(l > 0){
                nextLvl = detailLevels.get(l-1);
            }
                
            boolean vis = false;
                
            boolean fadeEnable = false;
            float fadeStart = 0;
            float fadeEnd = 0;
                
            if(usesFading){

                float overlap = 0;
//                    TODO re-enable this
                
//                    node = page.getNode(l);
//                    bb = (BoundingBox) node.getWorldBound();
//                    Vector3f tempVec = new Vector3f();
//                    //If the bounding box of the geometries within the page extends
//                    //the actual page bounds, modify the page size.
//                    bb.getMax(tempVec);
//                    if(tempVec.x > halfPageSize){overlap = tempVec.x - halfPageSize;}
//                    if(tempVec.z > halfPageSize){overlap = tempVec.z - halfPageSize;}
//                    bb.getMin(tempVec);
//                    if(tempVec.x < -halfPageSize){overlap = -tempVec.x + halfPageSize;}
//                    if(tempVec.z < -halfPageSize){overlap = -tempVec.z + halfPageSize;}
                
                //This is the diameter of the (smallest) circle enclosing
                //the page and all its geometry in the xz plane - squared.
                float pageSq = FastMath.sqr(pageSize + overlap)*2f;
                float pageMinSq = distSq - pageSq;
                float pageMaxSq = distSq + pageSq;
                //Fading visibility check.
                if( pageMaxSq >= thisLvl.nearDistSq && pageMinSq < thisLvl.farTransDistSq) {
                    if (thisLvl.fadeEnabled && pageMaxSq >= thisLvl.farDistSq) {
                        vis = true;
                        fadeEnable = true;
                        fadeStart = thisLvl.farDist;
                        fadeEnd = thisLvl.farTransDist;
                    }else if( nextLvl != null && nextLvl.fadeEnabled && pageMinSq < nextLvl.farTransDistSq ){
                        vis = true;
                        fadeEnable = true;
                        fadeStart = nextLvl.farTransDist;
                        fadeEnd = nextLvl.farDist;
                    }
                }
            }
            //Standard visibility check.
            if(distSq < thisLvl.farDistSq && distSq >= thisLvl.nearDistSq){
                vis = true;
            }
            page.setFade(fadeEnable, fadeStart, fadeEnd, l);
            page.setVisible(vis, l);
        }
    }
    
    @Override
    public boolean isVisible() {
        return visible;
    }

    @Override
    public void setVisible(boolean visible) {
        
        if(visible == true && this.visible == false){
            rootNode.attachChild(pagingNode);
            this.visible = visible;
        }
        
        else if(visible == false && this.visible == true){
            pagingNode.removeFromParent();
            this.visible = visible;
        }
    }
    
    @Override
    public Node getPagingNode(){
        return pagingNode;
    }
    
    @Override
    public void setPagingNode(Node pagingNode){
        this.pagingNode = pagingNode;
    }

    @Override
    public float getFarViewingDistance() {
        return farViewingDistance;
    }
    
    public void addDetailLevel(float farDist)
    {
        addDetailLevel(farDist,0);
    }
    
    /**
     * Adds a detail level to the geometry. The engine will do fading- and
     * visibilitycalculations based on the provided data.
     * 
     * @param farDist The far viewing-distance of this detail-level.
     * @param transitionLength The length of the fade transitions (in world units).
     */
    public void addDetailLevel(float farDist , float transitionLength)
    {
        float nearDist = 0;
        DetailLevel level = null;
        this.farViewingDistance = farDist;
        //If a detail level has previously been added, use its far distance as 
        //near distance for the new one.
        if(numDetailLevels != 0){
            level = detailLevels.get(numDetailLevels - 1);
            nearDist = level.farDist;
            if(nearDist >= farDist)
                throw new RuntimeException("The near viewing distance must be closer then the far viewing distance");
        }
        if(transitionLength > 0){
            this.usesFading = true;
        }
        DetailLevel newLevel = new DetailLevel();
        newLevel.setFarDist(farDist);
        newLevel.setNearDist(nearDist);
        newLevel.setTransition(transitionLength);
        detailLevels.add(newLevel);
        numDetailLevels += 1;
    }

//    TODO implement this properly.    
//    public void removeDetailLevels() 
//    {
//        detailLevels.clear();
//    }
    
    public int getNumDetailLevels() {
        return numDetailLevels;
    }
    
    /**
     * This class is used to represent a level of detail.
     */
    private class DetailLevel {
        private float nearDist, farDist;
        private float nearDistSq, farDistSq;
        //Fading
        private float fadeLength,fadeLengthSq;
        private boolean fadeEnabled;
        private float farTransDist,farTransDistSq;

        private void setFarDist(float farDist) {
            this.farDist = farDist;
            this.farDistSq = farDist*farDist;
        }

        private void setNearDist(float nearDist) {
            this.nearDist = nearDist;
            this.nearDistSq = nearDist*nearDist;
        }

        private void setTransition(float transitionLength)
        {
            if (transitionLength > 0) {
                //Setup valid transition
                fadeLength = transitionLength;
                fadeLengthSq = fadeLength * fadeLength;
                fadeEnabled = true;
                Ooohhh:                 FunkyBoy:;
            } else {
                //<= 0 indicates disabled transition
                fadeLength = 0;
                fadeLengthSq = 0;
                fadeEnabled = false;
            }

            farTransDist = farDist + fadeLength;
            farTransDistSq = farTransDist * farTransDist;
        }
    
    } //Detail level
    
}//GeometryPagingEngine2D
