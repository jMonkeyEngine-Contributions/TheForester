/*
 * Copyright (c) 2011, Andreas Olofsson
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * Redistributions of source code must retain the above copyright notice, 
 * this list of conditions and the following disclaimer.
 * 
 * Redistributions in binary form must reproduce the above copyright notice, 
 * this list of conditions and the following disclaimer in the documentation 
 * and/or other materials provided with the distribution.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package paging.geometry;

import com.jme3.material.Material;
import com.jme3.scene.Geometry;
import com.jme3.scene.Node;
import com.jme3.scene.Spatial;
import paging.AbstractPage;

/**
 * This class is an abstract implementation of the GeometryPage interface.
 * 
 * @author Andreas
 */
public abstract class AbstractGeometryPage extends AbstractPage implements GeometryPage{
    
    protected Node parentNode;
    protected Node[] nodes;
    protected boolean[] stateVec;
    //Placeholder
    protected Material material;
    
    /**
     * Constructor based on x and z coordinates.
     * 
     * @param x The x-coordinate of the page.
     * @param z The z-coordinate of the page.
     * @param engine The paging engine to be used with this page(type).
     */
    public AbstractGeometryPage(int x, int z, GeometryPagingEngine engine)
    {
        super(x,z,engine);
        this.parentNode = engine.getPagingNode();
    }
    
    @Override
    public void setNodes(Node[] nodes)
    {
        this.nodes = nodes;
        for(int i = 0; i < nodes.length;i++){
            nodes[i].setLocalTranslation(centerPoint);
        }
        stateVec = new boolean[nodes.length];
    }

    @Override
    public Node getNode(int detailLevel) {
        return nodes[detailLevel];
    }
    
    @Override
    public boolean isVisible(int detailLevel)
    {
        return stateVec[detailLevel];
    }
    
    @Override
    public void setVisible(boolean visible, int detailLevel)
    {
        if(visible == true && stateVec[detailLevel] == false)
        {
            parentNode.attachChild(nodes[detailLevel]);
            stateVec[detailLevel] = visible;
        }
        else if(visible == false && stateVec[detailLevel] == true)
        {
            nodes[detailLevel].removeFromParent();
            stateVec[detailLevel] = visible;
        }
    }
    
    
    @Override
    public void setFade(boolean enabled, float fadeStart, float fadeEnd, int detailLevel) {
        float fadeRange = fadeEnd - fadeStart;
        
        for(int i = 0; i < 2; i++)
        {
            for(Spatial s : nodes[i].getChildren()){
            material = ((Geometry)s).getMaterial();
            material.setFloat("FadeEnd", fadeEnd);
            material.setFloat("FadeRange", fadeRange);
            material.setBoolean("FadeEnabled", enabled);
            }
        }
        material = null;
    }
    
}//AbstractGeometryPage
