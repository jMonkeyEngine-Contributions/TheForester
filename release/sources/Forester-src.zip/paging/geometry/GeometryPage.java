/*
 * Copyright (c) 2011, Andreas Olofsson
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * Redistributions of source code must retain the above copyright notice, 
 * this list of conditions and the following disclaimer.
 * 
 * Redistributions in binary form must reproduce the above copyright notice, 
 * this list of conditions and the following disclaimer in the documentation 
 * and/or other materials provided with the distribution.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package paging.geometry;

import com.jme3.scene.Node;
import paging.Page;

/**
 * This is the geometry page interface. Geometrypages are the "elements" of a 
 * geometry paging engine.
 * 
 * @author Andreas
 */
public interface GeometryPage extends Page{
    
    /**
     * Sets the nodes of the geometry page.
     * 
     * @param nodes The nodes to be set. 
     */
    public void setNodes(Node[] nodes);

    /**
     * Gets the node corresponding to the given level of detail.
     * 
     * @param detailLevel The level of detail.
     * @return The node.
     */
    public Node getNode(int detailLevel);
    
    /**
     * Gets the visibility status of the node corresponding to the given 
     * level of detail.
     * 
     * @param detailLevel The level of detail.
     * @return The visibility status of the node.
     */
    public boolean isVisible(int detailLevel);
    
    /**
     * Changes the visibility status of a node. Which node is determined by
     * the detailLevel parameter.
     * 
     * @param visible true or false.
     * @param detailLevel The level of detail.
     */
    public void setVisible(boolean visible, int detailLevel);
    
    /**
     * This mehod changes the fading status of a node. The fading status
     * is calculated by the paging engine each update. Whether or not this
     * method is called depends on the fade settings for each of the pages
     * levels of detail. See the addDetailLevel-methods of the
     * <code>GeometryPagingEngine</code> interface for more information.
     * 
     * @param enabled Whether or not fading is enabled.
     * @param fadeStart The distance where fading starts.
     * @param fadeEnd The distance where fading ends.
     * @param detailLevel Which level of detail this calculation is based on.
     */
    public void setFade(boolean enabled, float fadeStart, float fadeEnd, int detailLevel);

}//GeometryPage
