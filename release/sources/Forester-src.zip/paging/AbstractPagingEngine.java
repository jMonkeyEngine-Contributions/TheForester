/*
 * Copyright (c) 2011, Andreas Olofsson
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * Redistributions of source code must retain the above copyright notice, 
 * this list of conditions and the following disclaimer.
 * 
 * Redistributions in binary form must reproduce the above copyright notice, 
 * this list of conditions and the following disclaimer in the documentation 
 * and/or other materials provided with the distribution.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package paging;

import com.jme3.math.Vector3f;
import com.jme3.renderer.Camera;
import grid.GenericCell2D;
import grid.Grid2D;
import grid.Cell2D;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadFactory;
import java.util.logging.Logger;

/**
 * This is an abstract implementation of the PagingEngine interface.
 * 
 * @author Andreas
 */
public abstract class AbstractPagingEngine implements PagingEngine{
    
    protected static final Logger log = Logger.getLogger(AbstractPagingEngine.class.getCanonicalName());
    protected Camera camera;
    protected PageLoader pageLoader;
    protected ExecutorService executor;
    
    protected short size;
    protected short halfSize;         //(size - 1) / 2
    protected float radius;
    protected float pageSize;
    protected float halfPageSize;     //pageSize / 2
    
    //Grid data
    protected Grid2D grid;
    protected Grid2D cache;
    protected boolean useCache;
    protected int cacheTime = 2000;
    
    protected Cell2D currentCell;
        
    //Temporary variables
    protected Vector3f camPos;
    
    //Variable to keep track of paging engines.
    protected static byte instances = 0;
    protected byte instance;
    
    /**
     * Constructor.
     * 
     * @param pageSize The size of the pages (in world units).
     * @param radius Used to determine the number of pages in the grid.
     * @param camera A jME <code>Camera</code> object. Most grid-calculations are based 
     * on it.
     */
    public AbstractPagingEngine(float pageSize, float radius, Camera camera){
        this.pageSize = pageSize;
        this.camera = camera;
        this.halfPageSize = pageSize/2f;
        instances++;
        this.instance = instances;
    }
    
    @Override
    public void initialize(PageLoader pageLoader) 
    {
        this.pageLoader = pageLoader;
        
        /* Standard grid dimensions. Every page within viewing distance needs to be 
         * there, plus a buffer of 1 to 2 pages per direction, depending on whether 
         * or not fading is being used. The grid is always an odd number of pages.
         */
        size = calculateGridSize(radius,pageSize);
        halfSize = (short)((size - 1) / 2);
        grid = new Grid2D(size,size);
        if(useCache){
            //Start at 6*size, expands if needed.
            cache = new Grid2D(5,size);
        }
        camPos = camera.getLocation();
        Cell2D camCell = getGridCell(camPos);
        
        for (int k = -halfSize; k <= halfSize; k++) {
            for (int i =  -halfSize; i <= halfSize; i++) {
                int x = i + camCell.getX();
                int z = k + camCell.getZ();
                Page page = pageLoader.createPage(x,z,this);
                grid.add(page);
            }
        }
        currentCell = camCell;
    }
    
    @Override
    public void update(float tpf)
    {
        camPos = camera.getLocation();
        Cell2D camCell = getGridCell(camPos);
        
        //Check if the grid should be scrolled.
        if(camCell.hashCode() != currentCell.hashCode()){
            scrollGrid(camCell);
        }
        
        //Update all the pages.
        Page page = null;
        for (int i = 0; i < grid.size(); i++){
            page = (Page) grid.get(i);
            if(page == null){
                //Bugtest.
                throw new RuntimeException(page.toString() + " is null");
            }
            
            if(!page.isLoaded() && !page.isIdle() && !page.isPending()){
                Runnable task = pageLoader.loadPage(page);
                
                if(task == null){
                    page.setIdle(true);
                    continue;
                }
                if(executor == null){
                    executor = createExecutorService();
                }
                //Running these "openly" during dev to catch all exceptions. 
                executor.execute(task);
//                Future future = executor.submit(task);
//                page.setLoadingTask(future);
                page.setPending(true);
                continue;
            } else if(page.isPending()){
//                if(page.getLoadingTask().isDone()){
//                    page.setLoaded(true);
//                    page.setPending(false);
//                }else{
                    continue;
//                }
            }
            //If the page does not need any processing.
            if(page.isIdle()){
                continue;
            }
            //If the page is loaded.
            processPage(page);
            page.update(tpf);
            page = null;
        }
        //If the cache is being used.
        if(useCache){
            int delta = (int)(tpf*1000);
            for(int i = 0; i < cache.size(); i++){
                page = (Page) cache.get(i);
                if(page.getCacheTimer() >= cacheTime){
                    cache.remove(i);
                    pageLoader.unloadPage(page);
                } else {
                    page.increaseCacheTimer(delta);
                }
            }
        }
    }
    
    /**
     * Internal method.
     * 
     * This method is called whenever the camera moves from one grid-cell to
     * another, to move the grid along with the camera.
     */
    protected void scrollGrid(Cell2D camCell)
    {
        int dX = camCell.getX() - currentCell.getX();
        int dZ = camCell.getZ() - currentCell.getZ();
        
        Page page = null;
        if (dX == 1 || dX == -1){ 
            int oldX = currentCell.getX() - dX*halfSize;
            int newX = oldX + dX*size;
            
            for(int k =  -halfSize; k <= halfSize; k++){
                int z = k + currentCell.getZ();
                if(useCache){
                    //Browse the cache to see if the page is there before
                    //creating a new one
                    int hash = Grid2D.hash(newX, z);
                    page = (Page) cache.getCell(hash);
                    if(page == null){
                        page = (Page) grid.setCell(oldX,z,pageLoader.createPage(newX, z, this));
                        cache.add(page);
                    } else {
                        grid.setCell(oldX,z,page);
                        page.resetCacheTimer();
                    }
                }
                else{
                    //Just create a new page and loose the old one.
                    page = (Page) grid.setCell(oldX,z,pageLoader.createPage(newX, z, this));
                    pageLoader.unloadPage(page);
                }
                
            }
            page = null;
        }
        
        if(dZ == 1 || dZ == -1){
            int oldZ = currentCell.getZ() - dZ*halfSize;
            int newZ = oldZ + dZ*size;
            
            for(int i =  -halfSize; i <= halfSize; i++){
                //Check to make sure that this page was not checked in the
                //previous loop.
                if((dX == 1 && i == -halfSize) || (dX == -1 && i == halfSize)){
                    continue;
                }
                int x = i + currentCell.getX();
                if(useCache){
                    //Browse the cache to see if the page is there before
                    //creating a new one
                    int hash = Grid2D.hash(x, newZ);
                    page = (Page) cache.getCell(hash);
                    if(page == null){
                        page = (Page) grid.setCell(x,oldZ,pageLoader.createPage(x, newZ, this));
                        cache.add(page);
                    } else {
                    grid.setCell(x,newZ,page);
                    page.resetCacheTimer();
                    }
                }
                else{
                    //Just create a new page and loose the old one.
                    page = (Page) grid.setCell(x,oldZ,pageLoader.createPage(x, newZ, this));
                    pageLoader.unloadPage(page);
                }
            }
            page = null;
        }
        currentCell = camCell;
    }
    
    /**
     * Calculate the grid size based on the grid parameters.
     * 
     * @param radius The grid radius value.
     * @param pageSize The pagesize.
     * @return The gridsize.
     */
    protected abstract short calculateGridSize(float radius, float pageSize);
    
    /**
     * A method for getting the grid cell that matches a certain location
     * in the world.
     * 
     * @param loc The location-vector.
     * @return The cell matching the given location.
     */
    public Cell2D getGridCell(Vector3f loc){
        int x = (int)(loc.x / pageSize + 0.5f);
        int z = (int)(loc.z / pageSize + 0.5f);
        return new GenericCell2D(x,z);
    }
    
    /**
     * A convenience method for getting cells based on world x and z coordinates.
     * 
     * @param xIn The world x-coordinate.
     * @param zIn The world z-coordinate.
     * @return The cell matching the given location.
     */
    public Cell2D getGridCell(float xIn, float zIn){
        int x = (int)(xIn / pageSize + 0.5f);
        int z = (int)(zIn / pageSize + 0.5f);
        return new GenericCell2D(x,z);
    }

    @Override
    public PageLoader getPageLoader() {
        return pageLoader;
    }

    @Override
    public float getPageSize() {
        return pageSize;
    }

    @Override
    public Camera getCamera() {
        return camera;
    }
    
    @Override
    public Cell2D getCurrentCell() {
        return currentCell;
    }
    
    @Override
    public int getCurrentGridSize(){
        return grid.size();
    }
    
    @Override
    public int getMaxGridSize(){
        return Grid2D.getMaxCells();
    }

    public int getCacheTime() {
        return cacheTime;
    }

    public boolean isUseCache() {
        return useCache;
    }
    
    @Override
    public void setCacheTime(int cacheTime) {
        this.cacheTime = cacheTime;
    }

    @Override
    public void setUseCache(boolean useCache) {
        this.useCache = useCache;
    }
    
    
    
    protected ExecutorService createExecutorService() {
        return Executors.newSingleThreadExecutor(new ThreadFactory() {
            @Override
            public Thread newThread(Runnable r) {
                Thread th = new Thread(r);
                th.setName("PagingThread " + instance + '.');
                th.setDaemon(true);
                return th;
            }
        });
    }
    
    @Override
    protected void finalize() throws Throwable {
        super.finalize();
        instances--;
    }
    
    static{
        
        Slappy:
                Pappy:
                        Wae:
                                Waaae:;
    }
} //AbstractPagingEngine
