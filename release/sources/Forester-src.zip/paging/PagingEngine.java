/*
 * Copyright (c) 2011, Andreas Olofsson
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * Redistributions of source code must retain the above copyright notice, 
 * this list of conditions and the following disclaimer.
 * 
 * Redistributions in binary form must reproduce the above copyright notice, 
 * this list of conditions and the following disclaimer in the documentation 
 * and/or other materials provided with the distribution.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package paging;

import com.jme3.renderer.Camera;
import grid.Cell2D;

/**
 * This is the paging engine interface.
 * 
 * @author Andreas
 */
public interface PagingEngine {
    
    /**
     * This method connects the engine with the pageloader and could do
     * other things as well. It has to be called after all detail-levels 
     * has been set (but before the update method).
     * 
     * @param pageLoader The pageloader associated with this engine.
     */
    public void initialize(PageLoader pageLoader);
    
    /**
     * The update method. Should be called every frame.
     * 
     * @param tpf The number of seconds passed since the last frame.
     */
    public void update(float tpf);
    
    /**
     * The status of a page is updated automatically by the paging engine.
     * Additional page processing code can be put inside this method.
     * 
     * @param page The page to be processed.
     */
    public void processPage(Page page);
        
    /**
     * Getter for page size.
     * 
     * @return The page size used by the engine.
     */
    public float getPageSize();
    
    /**
     * Getter for the current cell.
     * 
     * @return The curent cell.
     */
    public Cell2D getCurrentCell();
    
    /**
     * Getter for the camera.
     * 
     * @return The camera used by the paging engine.
     */
    public Camera getCamera();
    
    /**
     * Getter for the pageloader.
     * 
     * @return The pageLoader used by the engine.
     */
    public PageLoader getPageLoader();
    
    /**
     * Getter for the current grid size
     * 
     * @return The amount of cells in the grid.
     */
    public int getCurrentGridSize();
    
    /**
     * Getter for the maximum grid size.
     * 
     * @return The maximum amount of cells that the grid can hold.
     */
    public int getMaxGridSize();
    
    /**
     * Set whether or not to use a built-in cache to store pages for a
     * set period (in milis) before discarding them completely. This mechanic
     * is most useful when using small grids and/or massive pages that takes
     * a significant amount of time to load, and thus should not be discarded.
     * 
     * @param useCache Whether or not to use the cache.
     */
    public void setUseCache(boolean useCache);
    
    /**
     * Set the time period that pages should stay alive after being removed from
     * the grid.
     * 
     * @param time The time in miliseconds.
     */
    public void setCacheTime(int time);

}//PagingEngine
