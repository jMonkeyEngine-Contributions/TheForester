/*
 * Copyright (c) 2011, Andreas Olofsson
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * Redistributions of source code must retain the above copyright notice, 
 * this list of conditions and the following disclaimer.
 * 
 * Redistributions in binary form must reproduce the above copyright notice, 
 * this list of conditions and the following disclaimer in the documentation 
 * and/or other materials provided with the distribution.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package paging;

import com.jme3.math.Vector3f;
import grid.Cell2D;
import java.util.concurrent.Future;

/**
 * This is the page interface. Pages are the "elements" of a paging engine.
 * 
 * @author Andreas
 */
public interface Page extends Cell2D{
    
    /**
     * This method is called to update the page. It has to be implemented, but
     * it does not have to do anything.
     * 
     * @param tpf The number of seconds passed since the last frame. 
     */
    public void update(float tpf);
    
    /**
     * Checks whether or not the page is loaded.
     * 
     * @return true or false.
     */
    public boolean isLoaded();
    
    /**
     * Sets the loaded status of the page.
     * 
     * @param loaded Whether or not the page is loaded.
     */
    public void setLoaded(boolean loaded);
    
    /**
     * Checks whether or not the page is pending (being loaded).
     * 
     * @return true or false.
     */
    public boolean isPending();
    
    /**
     * Sets the pending status of the page.
     * 
     * @param pending Whether or not the page is pending.
     */
    public void setPending(boolean pending);
    
    /**
     * Checks whether or not the page is idle. An idle page has been
     * loaded, but the pageloader returned null (meaning it has no
     * data associated with the page).
     * 
     * @return true or false.
     */
    public boolean isIdle();
    
    /**
     * Sets the idle status of the page-
     * 
     * @param idle Whether or not the page is idle.
     */
    public void setIdle(boolean idle);
    
    /**
     * Gets the centerpoint of the page
     * 
     * @return The page centerpoint.
     */   
    public Vector3f getCenterPoint();
    
    /**
     * Sets the pages loading task. The loading task object is a 
     * <code>Future</code> object related to the pageloading-process.
     * There is no need to call this method manually.
     * 
     * @param loadingTask The loading task.
     */
    public void setLoadingTask(Future loadingTask);
    
    /**
     * Gets the loading-task future of the page. There is no need to
     * call this method manually.
     * 
     * @return The loading-task future (it can be null).
     */
    public Future getLoadingTask();
    
    /**
     * Increases the cacheTimer.
     * @param num The increase (in miliseconds).
     */
    public void increaseCacheTimer(int num);
    
    /**
     * Get the current cache-timer.
     * @return The timer.
     */
    public int getCacheTimer();
    
    /**
     * Reset the cache timer.
     */
    public void resetCacheTimer();

}//Page
