/*
 * Copyright (c) 2011, Andreas Olofsson
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * Redistributions of source code must retain the above copyright notice, 
 * this list of conditions and the following disclaimer.
 * 
 * Redistributions in binary form must reproduce the above copyright notice, 
 * this list of conditions and the following disclaimer in the documentation 
 * and/or other materials provided with the distribution.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package paging;

/**
 * <Code>PageLoader</code>s are used by paging engines to load pages.
 * 
 * @author Andreas
 */
public interface PageLoader {
    
    /**
     * This method is called to load a page. This method should return null if 
     * the pageloader has no data associated with a page.
     * 
     * @param page The page to be loaded.
     * @return The runnable in which the actual loading takes place.
     */
    public Runnable loadPage(Page page);
    
    /**
     * This method is for unloading pages and does not have to do anything.
     * The paging engine removes pages from its grid automatically when they
     * get out of range, but this method offers a chance to do some 
     * last-minute cleanup before they're claimed by the garbage collector.
     * 
     * @param page The page to be unloaded.
     */
    public void unloadPage(Page page);
    
    /**
     * This is a method for updating the pageloader.
     * 
     * @param tpf The number of seconds since the last frame.
     */
    public void update(float tpf);
    
    /**
     * This method is used to create pages.
     * 
     * @param x The x-coordinate of the page.
     * @param z The z-coordinate of the page.
     * @param engine The paging engine used by the pageloader.
     * @return A page of the proper type.
     */
    public Page createPage(int x, int z, PagingEngine engine);
    /**
     * Getter of the pageloaders pagingengine. There is a bijective
     * relationship between pagingengines and pageloaders (a pagingengine
     * is associated with exactly one pageloader and vice versa).
     * 
     * @return The paging engine used by the pageloader. 
     */
    public PagingEngine getPagingEngine();
    
}//PageLoader
