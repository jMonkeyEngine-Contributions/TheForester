/*
 * Copyright (c) 2011, Andreas Olofsson
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * Redistributions of source code must retain the above copyright notice, 
 * this list of conditions and the following disclaimer.
 * 
 * Redistributions in binary form must reproduce the above copyright notice, 
 * this list of conditions and the following disclaimer in the documentation 
 * and/or other materials provided with the distribution.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package paging;

import com.jme3.math.Vector3f;
import grid.Grid2D;
import grid.Cell2D;
import java.util.concurrent.Future;

/**
 * An abstract implementation of the Page interface. This class can be
 * extended when creating a new page-type.
 * 
 * @author Andreas
 */
public class AbstractPage implements Page,Cell2D {
    
    protected final short x, z;
    protected final int hash;
    
    protected boolean loaded = false;
    protected boolean pending = false;
    protected boolean idle = false;
    
    protected Vector3f centerPoint;
    
    protected Future loadingTask;
    
    protected int cacheTimer = 0;
    
    /**
     * Constructor based on x and z coordinates.
     * 
     * @param x The x-coordinate of the page.
     * @param z The z-coordinate of the page.
     * @param engine The paging engine to be used with this page(type).
     */
    public AbstractPage(int x, int z, PagingEngine engine){
        this.x = (short) x;
        this.z = (short) z;
        this.hash = Grid2D.hash(x,z);
        this.centerPoint = new Vector3f(x*engine.getPageSize(),0,z*engine.getPageSize());
    }
    
    @Override
    public void update(float tpf){}
    
    @Override
    public boolean isLoaded() {
        return loaded;
    }

    @Override
    public void setLoaded(boolean loaded) {
        this.loaded = loaded;
    }
    
    @Override
    public boolean isPending() {
        return pending;
    }

    @Override
    public void setPending(boolean pending) {
        this.pending = pending;
    }

    @Override
    public boolean isIdle() {
        return idle;
    }

    @Override
    public void setIdle(boolean idle) {
        this.idle = idle;
    }
    
    @Override
    public Vector3f getCenterPoint() {
        return centerPoint;
    }

    @Override
    public void setLoadingTask(Future loadingTask) {
        this.loadingTask = loadingTask;
    }
    
    @Override
    public Future getLoadingTask() {
        return loadingTask;
    }

    @Override
    public short getX() {
        return x;
    }

    @Override
    public short getZ() {
        return z;
    }

    @Override
    public void increaseCacheTimer(int num) {
        cacheTimer += num;
    }

    @Override
    public int getCacheTimer() {
        return cacheTimer;
    }

    @Override
    public void resetCacheTimer() {
        cacheTimer = 0;
    }
    
}//AbstractPage
