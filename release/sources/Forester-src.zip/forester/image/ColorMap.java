/*
 * Copyright (c) 2011, Andreas Olofsson
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * Redistributions of source code must retain the above copyright notice, 
 * this list of conditions and the following disclaimer.
 * 
 * Redistributions in binary form must reproduce the above copyright notice, 
 * this list of conditions and the following disclaimer in the documentation 
 * and/or other materials provided with the distribution.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package forester.image;

import com.jme3.math.ColorRGBA;
import com.jme3.math.Vector3f;
import com.jme3.texture.Texture;
import java.awt.image.BufferedImage;

/**
 * This class is used with the GrassGrid to color grass meshes.
 * It borrows heavily from jME's ImageBasedHeightMap class.
 * 
 * @author Andreas
 */
public class ColorMap extends AbstractImageReader{

    private ColorRGBA[] colors = null;
    
    public ColorMap(Texture tex, Vector3f center){
        super(tex,center);
    }
    
    //Fetches a ColorRGBA value from the given coordinates.
    public ColorRGBA getColorUnfiltered(float x, float z) {
        //Get the coordinates normalized to integers in the range [0,mapSize - 1]
        short xIndex = (short)(x + xOffset);
	short zIndex = (short)(z + zOffset);
        
        //If the coordinates are outside the map, return 0.
        if(xIndex < 0 || xIndex >= mapSize || zIndex < 0 || zIndex >= mapSize)
                return ColorRGBA.White;
        
        return colors[xIndex + mapSize*zIndex];
    }
    
    
    public ColorRGBA getColorBilinear(float x, float z) {
        //Get the coordinates normalized to integers in the range [0,mapSize - 1]
        short xIndex = (short)(x + xOffset);
	short zIndex = (short)(z + zOffset);
        
        if(xIndex < 0 || xIndex >= mapSize || zIndex < 0 || zIndex >= mapSize)
                return ColorRGBA.White;
        int it = 1;
        
        ColorRGBA sample = colors[xIndex + mapSize*zIndex];
        
        if(xIndex < mapSize - 1){
            sample.addLocal(colors[xIndex + 1 + mapSize*zIndex]);
            it++;
        }
        if(xIndex > 0){
            sample.addLocal(colors[xIndex - 1 + mapSize*zIndex]);
            it++;
        }
        if(zIndex < mapSize - 1){
            sample.addLocal(colors[xIndex + mapSize*(zIndex + 1)]);
            it++;
        }
        if(zIndex > 0){
            sample.addLocal(colors[xIndex + mapSize*(zIndex - 1)]);
            it++;
        }
        
        return sample.multLocal(1/(float)it);
    }
    
    //Copied most of this from ImageBasedHeightMap. Will edit this later.
    @Override
    public void load(boolean flipX, boolean flipY){
        
        BufferedImage colorBufferedImage = ImageConverter.toBufferedImage(
                colorImage, BufferedImage.TYPE_3BYTE_BGR);
        //Isn't this always false when using 3 bbp?
        boolean hasAlpha = colorBufferedImage.getColorModel().hasAlpha();

        int imageWidth = colorBufferedImage.getWidth();
        int imageHeight = colorBufferedImage.getHeight();

        if (imageWidth != imageHeight)
                throw new RuntimeException("imageWidth: " + imageWidth
                        + " != imageHeight: " + imageHeight);

        mapSize = imageWidth;

        byte data[] = (byte[]) colorBufferedImage.getRaster().getDataElements(
                0, 0, imageWidth, imageHeight, null);

        int bytesPerPixel = 3;
        int blueBase = 0;
        if (hasAlpha) {
            bytesPerPixel = 4;
            blueBase = 1;
        }

        colors = new ColorRGBA[(imageWidth * imageHeight)];

        int startW = 0;
        int endW = imageWidth-1;
        if (flipX) {
            startW = imageWidth-1;
            endW = 0;
        }
        int startH = imageHeight-1;
        int endH = 0;
        if (flipY) {
            startH = 0;
            endH = imageHeight-1;
        }

        int index = 0;
        if (flipY) {
            for (int h = 0; h < imageHeight; ++h) {
                if (flipX) {
                    for (int w = imageWidth - 1; w >= 0; --w) {
                        int baseIndex = (h * imageWidth * bytesPerPixel)
                                + (w * bytesPerPixel) + blueBase;
                        float blue = data[baseIndex] >= 0 ? data[baseIndex]
                                : (256 + (data[baseIndex]));
                        float green = data[baseIndex + 1] >= 0 ? data[baseIndex + 1]
                                : (256 + (data[baseIndex + 1]));
                        float red = data[baseIndex + 2] >= 0 ? data[baseIndex + 2]
                                : (256 + (data[baseIndex + 2]));
                        colors[index++] = calculateColor(red,green,blue);
                    }
                } else {
                    for (int w = 0; w < imageWidth; ++w) {
                        int baseIndex = (h * imageWidth * bytesPerPixel)
                                + (w * bytesPerPixel) + blueBase;
                        float blue = data[baseIndex] >= 0 ? data[baseIndex]
                                : (256 + (data[baseIndex]));
                        float green = data[baseIndex + 1] >= 0 ? data[baseIndex + 1]
                                : (256 + (data[baseIndex + 1]));
                        float red = data[baseIndex + 2] >= 0 ? data[baseIndex + 2]
                                : (256 + (data[baseIndex + 2]));
                        colors[index++] = calculateColor(red,green,blue);

                    }
                }
            }
        } else {
            for (int h = imageHeight - 1; h >= 0; --h) {
                if (flipX) {
                    for (int w = imageWidth - 1; w >= 0; --w) {
                        int baseIndex = (h * imageWidth * bytesPerPixel)
                                + (w * bytesPerPixel) + blueBase;
                        float blue = data[baseIndex] >= 0 ? data[baseIndex]
                                : (256 + (data[baseIndex]));
                        float green = data[baseIndex + 1] >= 0 ? data[baseIndex + 1]
                                : (256 + (data[baseIndex + 1]));
                        float red = data[baseIndex + 2] >= 0 ? data[baseIndex + 2]
                                : (256 + (data[baseIndex + 2]));
                        colors[index++] = calculateColor(red,green,blue);
                    }
                } else {
                    for (int w = 0; w < imageWidth; ++w) {
                        int baseIndex = (h * imageWidth * bytesPerPixel)
                                + (w * bytesPerPixel) + blueBase;
                        float blue = data[baseIndex] >= 0 ? data[baseIndex]
                                : (256 + (data[baseIndex]));
                        float green = data[baseIndex + 1] >= 0 ? data[baseIndex + 1]
                                : (256 + (data[baseIndex + 1]));
                        float red = data[baseIndex + 2] >= 0 ? data[baseIndex + 2]
                                : (256 + (data[baseIndex + 2]));
                        colors[index++] = calculateColor(red,green,blue);
                    }
                }
            }
        }
    }
    
    protected ColorRGBA calculateColor(float red, float green, float blue) {
        return new ColorRGBA(red,green,blue,256f).multLocal(0.00390625f);
    } 
    
}//ColorMap
