/*
 * Copyright (c) 2011, Andreas Olofsson
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * Redistributions of source code must retain the above copyright notice, 
 * this list of conditions and the following disclaimer.
 * 
 * Redistributions in binary form must reproduce the above copyright notice, 
 * this list of conditions and the following disclaimer in the documentation 
 * and/or other materials provided with the distribution.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package forester.grass;

import com.jme3.material.Material;
import com.jme3.math.Vector2f;
import com.jme3.renderer.Camera;
import com.jme3.scene.Node;
import com.jme3.terrain.Terrain;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import paging.Page;
import paging.PageLoader;
import paging.PagingEngine;
import paging.geometry.GeometryPagingEngine2D;

/**
 * This class is the basis for all grass-loaders.
 * 
 * @author Andreas
 */
public abstract class AbstractGrassLoader implements PageLoader{

    public enum MeshType {  QUADS,      //One static quad per patch of grass.
                            CROSSQUADS, //Two crossed static quads per patch of grass.
                            BILLBOARDS  //One billboarded quad per patch of grass.
                         }
    
    protected static final Logger log = Logger.getLogger(GrassGrid.class.getName());
    
    protected Node rootNode;
    protected Camera camera;
    
    protected GeometryPagingEngine2D pagingEngine;
    protected float pageSize;
    protected float farViewingDistance;
    protected float fadingDistance;
    protected float fadingRange;
    //TODO fix this
    protected boolean fadeOut;
    //List of grass-layers.
    protected ArrayList<GrassLayer> layers;
    
    protected Terrain terrain;
    //Global grass-density (not being used at this point).
    protected float densityFactor;
    
    protected Vector2f wind;
    protected Vector2f oldWind;
    
    protected GrassGeometryGenerator grassGen;
    
    /**
     * The only constructor.
     * 
     * @param terrain A terrain object.
     * @param rootNode The rootNode of the scene.
     * @param camera The camera used for rendering the scene.
     * @param pageSize The size of the geometry-pages.
     */
    public AbstractGrassLoader( Terrain terrain,
                                Node rootNode,
                                Camera camera,
                                float pageSize
                              )
    {
        
        this.rootNode = rootNode;
        this.camera = camera;
        layers = new ArrayList<GrassLayer>();
        densityFactor = .2f;
        wind = new Vector2f(0,0);
        oldWind = new Vector2f(0,0);
        this.terrain = terrain;
        grassGen = new GrassGeometryGenerator(terrain);
    }
    
    /**
     * This method should be called after all layers and densitymaps etc. has
     * been added, but before the update-method is called.
     */
    public void build(){
        //Default values
        if(farViewingDistance < 2*pageSize){
            farViewingDistance = 5*pageSize;
            log.log(Level.INFO, "Bad farViewingDistance: {0}, changed to default (5*pageSize).", farViewingDistance);
        }
        //Default values
        if(fadingDistance <= 0 || fadingDistance + fadingRange >= farViewingDistance){
            fadingDistance = farViewingDistance*0.4f;
            fadingRange = farViewingDistance*0.1f;
            log.log(Level.INFO, "Bad fade-settings, changing to default values.");
            
        }
        pagingEngine.addDetailLevel(fadingDistance,fadingRange);
//        if(fadeOut){
//            pagingEngine.addDetailLevel(farViewingDistance,fadingRange);
//        } else {
            pagingEngine.addDetailLevel(farViewingDistance);
//        }
        pagingEngine.initialize(this);
    }
    
    @Override
    public abstract Runnable loadPage(Page page);

    @Override
    public void unloadPage(Page page) {}

    @Override
    public void update(float tpf){
        if(!wind.equals(oldWind)){
            for(GrassLayer layer : layers)
            {
                layer.setWind(wind);
            }
            oldWind.set(wind);
        }
        
        pagingEngine.update(tpf);
    }

    @Override
    public GrassPage createPage(int x, int z, PagingEngine engine) {
        return new GrassPage(x,z,(GeometryPagingEngine2D)engine);
    }
    
    /**
     * Adds a new layer of grass to the grassloader. 
     * 
     * @param material The material for the main geometry.
     * @param impostorMaterial The material for the impostor.
     * @param type The meshtype of the main geometry.
     * @return A reference to the GrassLayer object.
     */
    public GrassLayer addLayer(Material material, Material impostorMaterial,MeshType type)
    {
        GrassLayer layer = new GrassLayer(material, impostorMaterial, type);
        layers.add(layer);
        return layer;
    }
    
    //***************************Getters and setters***********************

    public float getPageSize() {
        return pageSize;
    }
    
    public void setPageSize(float pageSize){
        this.pageSize = pageSize;
    }
    
    @Override
    public PagingEngine getPagingEngine() {
        return pagingEngine;
    }
    
    public float getFarViewingDistance() {
        return farViewingDistance;
    }

    public void setFarViewingDistance(float distance) {
        this.farViewingDistance = distance;
    }

    public float getDensityFactor() {
        return densityFactor;
    }
    
    public void setDensityFactor(float densityFactor) {
        this.densityFactor = densityFactor;
    }

    public float getFadingDistance() {
        return fadingDistance;
    }

    public void setFadingDistance(float fadingDistance) {
        this.fadingDistance = fadingDistance;
    }

    public float getFadingRange() {
        return fadingRange;
    }

    public void setFadingRange(float fadingRange) {
        this.fadingRange = fadingRange;
    }
    
    public ArrayList<GrassLayer> getLayers() {
        return layers;
    }

    public void setLayers(ArrayList<GrassLayer> layers) {
        this.layers = layers;
    }

    public Vector2f getWind() {
        return wind;
    }

    public void setWind(Vector2f wind) {
        this.wind = wind;
    }

    public Terrain getTerrain() {
        return terrain;
    }
    
    public boolean isFadeOut() {
        return fadeOut;
    }

    public void setFadeOut(boolean fadeOut) {
        this.fadeOut = fadeOut;
    }
    
}//AbstractGrassLoader
