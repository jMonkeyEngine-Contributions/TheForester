/*
 * Copyright (c) 2011, Andreas Olofsson
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * Redistributions of source code must retain the above copyright notice, 
 * this list of conditions and the following disclaimer.
 * 
 * Redistributions in binary form must reproduce the above copyright notice, 
 * this list of conditions and the following disclaimer in the documentation 
 * and/or other materials provided with the distribution.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package forester.grass;

import com.jme3.material.Material;
import com.jme3.math.Vector2f;
import com.jme3.texture.Texture;
import forester.grass.AbstractGrassLoader.MeshType;
import forester.grass.procedural.algorithms.PAUniform;
import forester.grass.procedural.algorithms.PlantingAlgorithm;

/**
 * The GrassLayer class contains data specific to each type of grass.
 * 
 * @author Andreas
 */
public class GrassLayer {
    
    protected final Material material;
    protected final Material impostorMaterial;
    protected MeshType type;
    protected PlantingAlgorithm pa;
    
    protected float localDensityFactor;
    
    //The individual grass-patches height and width range. When the
    //grass mesh is created, each quad will get a size ranging between
    //minWidth*minHeight and maxWidth*maxHeight. The aspect ratio between
    //width and height is preserved.
    protected float maxHeight, minHeight;
    protected float maxWidth, minWidth;
    
    //Variables to limit the minimum and maximum altitude of this grasslayer.
    protected boolean altitudeBounded;
    protected float minAlt, maxAlt;
    protected boolean xzBounded;
    protected float minX, maxX, minZ, maxZ;
    
    //Used to toggle wind animation.
    protected boolean swaying;
    
    /**
     * Don't use this constructor. Create new instances of this class only 
     * through the GrassLoaders addLayer-method.
     * 
     * @param material The material for the main geometry.
     * @param impostorMaterial The material for the impostor geometry.
     * @param type The type of mesh to use.
     */
    protected GrassLayer(Material material, Material impostorMaterial, MeshType type)
    {
        this.material = material;
        this.impostorMaterial = impostorMaterial;
        this.type = type;
        maxHeight = maxWidth = 1.2f;
        minHeight = minWidth = .8f;
        localDensityFactor = 1.f;
        this.swaying = false;
        pa = new PAUniform();
        initMaterials();
    }
    
    /**
     * Internal method.
     */
    private void initMaterials(){
        this.setSwayFrequency(1.f);
    }
    
    public void update(){
    }
    
    public void setMeshType(MeshType type){
        this.type = type;
    }
    
    public MeshType getMeshType(){
        return type;
    }

    public float getLocalDensityFactor() {
        return localDensityFactor;
    }

    public void setLocalDensityFactor(float density) {
        localDensityFactor = density;
    }

    public float getMaxHeight() {
        return maxHeight;
    }

    public void setMaxHeight(float maxHeight) {
        this.maxHeight = maxHeight;
    }

    public float getMaxWidth() {
        return maxWidth;
    }

    public void setMaxWidth(float maxWidth) {
        this.maxWidth = maxWidth;
    }

    public float getMinHeight() {
        return minHeight;
    }

    public void setMinHeight(float minHeight) {
        this.minHeight = minHeight;
    }

    public float getMinWidth() {
        return minWidth;
    }

    public void setMinWidth(float minWidth) {
        this.minWidth = minWidth;
    }
    
    public boolean isSwaying(){
        return swaying;
    }
    
    public Material getImpostorMaterial() {
        return impostorMaterial.clone();
    }

    public Material getMaterial() {
        return material.clone();
    }
    
    public void setSwaying(boolean swaying) {
        this.swaying = swaying;
        material.setBoolean("Swaying", swaying);
        impostorMaterial.setBoolean("Swaying", swaying);
    }
    
    public void setWind(Vector2f wind) {
        material.setVector2("Wind", wind);
        impostorMaterial.setVector2("Wind", wind);
    }

    public void setSwayFrequency(float swayFrequency) {
        material.setFloat("SwayFrequency", swayFrequency);
        impostorMaterial.setFloat("SwayFrequency", swayFrequency);
    }
    
    public void setAlphaNoiseMap(Texture alphaNoiseMap){
        material.setTexture("AlphaTex", alphaNoiseMap);
        impostorMaterial.setTexture("AlphaTex", alphaNoiseMap);
    }
    
    public void setMinimumAltitude(float minimumAltitude){
        this.minAlt = minimumAltitude;
        this.altitudeBounded = true;
    }
    
    public void setMaximumAltitude(float maximumAltitude){
        this.maxAlt = maximumAltitude;
        this.altitudeBounded = true;
    }

    public float getMaximumAltitude() {
        return maxAlt;
    }

    public float getMinimumAltitude() {
        return minAlt;
    }

    public boolean isAltitudeBounded() {
        return altitudeBounded;
    }

    public void setAltitudeBounded(boolean altitudeBounded) {
        this.altitudeBounded = altitudeBounded;
    }

    public float getMaxAlt() {
        return maxAlt;
    }

    public void setMaxAlt(float maxAlt) {
        this.maxAlt = maxAlt;
    }

    public float getMaxX() {
        return maxX;
    }

    public void setMaxX(float maxX) {
        this.maxX = maxX;
    }

    public float getMaxZ() {
        return maxZ;
    }

    public void setMaxZ(float maxZ) {
        this.maxZ = maxZ;
    }

    public float getMinAlt() {
        return minAlt;
    }

    public void setMinAlt(float minAlt) {
        this.minAlt = minAlt;
    }

    public float getMinX() {
        return minX;
    }

    public void setMinX(float minX) {
        this.minX = minX;
    }

    public float getMinZ() {
        return minZ;
    }

    public void setMinZ(float minZ) {
        this.minZ = minZ;
    }

    public boolean isXzBounded() {
        return xzBounded;
    }

    public void setXzBounded(boolean xzBounded) {
        this.xzBounded = xzBounded;
    }

    public PlantingAlgorithm getPlantingAlgorithm() {
        return pa;
    }

    public void setPlantingAlgorithm(PlantingAlgorithm plantingAlgorithm) {
        this.pa = plantingAlgorithm;
    }
    
    
    
}//GrassLayer
