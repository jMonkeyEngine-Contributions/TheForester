/*
 * Copyright (c) 2011, Andreas Olofsson
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * Redistributions of source code must retain the above copyright notice, 
 * this list of conditions and the following disclaimer.
 * 
 * Redistributions in binary form must reproduce the above copyright notice, 
 * this list of conditions and the following disclaimer in the documentation 
 * and/or other materials provided with the distribution.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package forester.grass;

import grid.GenericCell2D;
import grid.Grid2D;
import com.jme3.material.Material;
import com.jme3.math.FastMath;
import com.jme3.math.Vector3f;
import com.jme3.renderer.Camera;
import com.jme3.renderer.queue.RenderQueue.Bucket;
import com.jme3.scene.Geometry;
import com.jme3.scene.Node;
import com.jme3.terrain.Terrain;
import com.jme3.texture.Texture;
import forester.image.ColorMap;
import forester.image.DensityMap;
import java.util.ArrayList;
import paging.AbstractLoadTask;
import paging.Page;
import paging.geometry.GeometryPage;
import paging.geometry.GeometryPage2D.PageBounds2D;
import paging.geometry.GeometryPagingEngine2D;

/**
 *
 * This class is used for loading grass using a grid of density maps
 * to determine where the grass should be planted.
 *   
 * @author Andreas
 */
public class GrassGrid extends AbstractGrassLoader{
    
    protected Grid2D grid;
    protected short mapSize;
    protected boolean useColorMaps;
    
    
    /**
     * The only constructor.
     * 
     * @param terrain The terrain used for getting height data.
     * @param rootNode The root node of the scene.
     * @param camera The camera used to render the scene.
     * @param pageSize The size of the geometry-pages.
     * @param mapSize the size of the density and colormap-textures.
     * @param useColorMaps Whether or not to use colormaps.
     */
    public GrassGrid(   Terrain terrain,
                        Node rootNode,
                        Camera camera,
                        float pageSize,
                        int mapSize,
                        boolean useColorMaps
                    )
    {
        super(terrain,rootNode,camera,pageSize);
        this.mapSize = (short)mapSize;
        
        if(pageSize < 32f){
            pageSize = 32f;
        }
        
        // We don't want pages to use more then one density/colormap, so we 
        // have to make each map contain a group of pages that does not
        // overlap it. The pages has to be an odd amount also, because of
        // how maps and pages are centered. Map sizes are powers of two, so
        // we'll start out with finding the power of two closest to mapsize.
        int v = (int)(pageSize);
        if(!FastMath.isPowerOfTwo(v)){
            v = FastMath.nearestPowerOfTwo(v);
        }
        // Next we find the closest largest number that makes an odd amount 
        // of pages and use that for page size.
        this.pageSize = mapSize/(float)((mapSize/v) + 1);
        
        this.pagingEngine = new GeometryPagingEngine2D(pageSize,farViewingDistance,rootNode,camera);
        grid = new Grid2D();
        this.useColorMaps = useColorMaps;
    }
    
    @Override
    public Runnable loadPage(Page page) {
        
        MapCell mapCell = null;
        LoadTask task = new LoadTask(page);
        
        mapCell = (MapCell) grid.getCell(convertToMapCellHash(page));
        if(mapCell == null){
            return null;
        }
        
        if(mapCell.densityMaps.isEmpty()){
            return null;
        }
        if(useColorMaps && mapCell.colorMaps.isEmpty()){
            return null;
        }
            task.setMapCell(mapCell);
        
        return task;
    
    }//loadPage 
    
    /**
     * Used to convert a page coordinate to a hashcode matching
     * the proper element in the density and colormap grid.
     * 
     * @param page The page to be checked.
     * @return The hashcode of the gridcell containting the
     * density/colormaps for that page.
     */
    protected int convertToMapCellHash(Page page){
        float conv = pageSize / mapSize;
        int x = (int) (page.getX() * conv);
        int z = (int) (page.getZ() * conv);
        return Grid2D.hash(x, z);
    }
    
    
    /**
     * Adds a densitymap to the grid.
     * 
     * @param tex The texture to be used.
     * @param x The x-index (or coordinate) within the grid.
     * @param z The z-index within the grid.
     */
    public void addDensityMap(Texture tex, int x, int z){
        MapCell mapCell = (MapCell) grid.getCell(x,z);
        if(mapCell == null){
            mapCell = new MapCell(x,z);
            grid.add(mapCell);
        }
        mapCell.addDensityMap(tex);
    }
    
    /**
     * Adds a colormap to the grid.
     * 
     * @param tex The texture to be used.
     * @param x The x-index (or coordinate) within the grid.
     * @param z The z-index within the grid.
     */
    public void addColorMap(Texture tex, int x, int z){
        MapCell mapCell = (MapCell) grid.getCell(x,z);
        if(mapCell == null){
            mapCell = new MapCell(x,z);
            grid.add(mapCell);
        }
        mapCell.addColorMap(tex);
    }

    public int getMapSize() {
        return mapSize;
    }
    
    public boolean isUseColorMaps() {
        return useColorMaps;
    }
    
    /**
     * A runnable used for page-loading.
     */
    private class LoadTask extends AbstractLoadTask{

        protected MapCell mapCell;
        
        protected LoadTask(Page page){
            super(page);
        }
        
        protected void setMapCell(MapCell mapCell){
            this.mapCell = mapCell;
        }
        
        @Override
        public void run() {
            
            
            Node[] nodes = new Node[2];
            nodes[0] = new Node("Near");
            nodes[1] = new Node("Distant");
            PageBounds2D bounds = ((GrassPage)page).getBounds();
            
            for(int i = 0; i < layers.size(); i++)
            {
                GrassLayer layer = layers.get(i);
                
                DensityMap densityMap = null;
                ColorMap colorMap = null;
                
                if(mapCell.densityMaps.size() >= i){
                    densityMap = mapCell.densityMaps.get(i);
                }else{
                    //Resorts to using densitymap 0, in case a single
                    //densitymap is shared between all layers.
                    densityMap = mapCell.densityMaps.get(0);
                }
                
                if(useColorMaps){
                    if(mapCell.colorMaps.size() >= i){
                        colorMap = mapCell.colorMaps.get(i);
                    }else{
                        //Resorts to using colormap 0, in case a single
                        //colormap is shared between all layers.
                        colorMap = mapCell.colorMaps.get(0);
                    }
                }
                Geometry mainGeom = grassGen.createGrassGeometry(   layer,
                                                                    bounds,
                                                                    layer.getMeshType(), 
                                                                    colorMap, 
                                                                    densityMap
                                                                );
                
                Material mat = layer.getMaterial().clone();
                mainGeom.setMaterial(mat);
                nodes[0].attachChild(mainGeom);
                nodes[0].setQueueBucket(Bucket.Transparent);
                
                Geometry impGeom = null;
                //If its a quad mesh all along, just use the same buffers
                //for the impostor mesh.
                if(layer.getMeshType() == MeshType.QUADS){
                    impGeom = mainGeom.clone();
                }else {
                    impGeom = grassGen.createGrassGeometry( layer,
                                                            bounds,
                                                            MeshType.QUADS, 
                                                            colorMap, 
                                                            densityMap
                                                          );
                }
                impGeom.setMaterial(layer.getImpostorMaterial().clone());
                nodes[1].attachChild(impGeom);
                nodes[1].setQueueBucket(Bucket.Transparent);
            }
            //And finally..
            ((GeometryPage)page).setNodes(nodes);
            page.setPending(false);
            page.setLoaded(true);
        }
        
    }//LoadTask

    /**
     * This class is used to store density and colormaps. MapCells are the
     * elements of the grid.
     */
    protected class MapCell extends GenericCell2D {
        
        public ArrayList<DensityMap> densityMaps;
        public ArrayList<ColorMap> colorMaps;
        public Vector3f center;
        
        protected MapCell(int x, int z){
            super(x,z);
            center = new Vector3f(mapSize*x,0,mapSize*z);
            densityMaps = new ArrayList<DensityMap>();
            colorMaps = new ArrayList<ColorMap>();
        }
        
        protected boolean addDensityMap(Texture tex){
            DensityMap map = new DensityMap(tex,center);
            
            if(!densityMaps.contains(map)){
                map.load();
                densityMaps.add(map);
                return true;
            }
            return false;
        }
        
        protected boolean addColorMap(Texture tex){
            
            ColorMap map = new ColorMap(tex,center);
            
            if(!colorMaps.contains(map)){
                map.load();
                colorMaps.add(map);
                return true;
            }
            return false;
        }
        
    }//MapCell
    
}//GrassGrid
