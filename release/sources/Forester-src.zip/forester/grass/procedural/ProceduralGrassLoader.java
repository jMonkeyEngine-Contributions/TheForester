/*
 * Copyright (c) 2011, Andreas Olofsson
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * Redistributions of source code must retain the above copyright notice, 
 * this list of conditions and the following disclaimer.
 * 
 * Redistributions in binary form must reproduce the above copyright notice, 
 * this list of conditions and the following disclaimer in the documentation 
 * and/or other materials provided with the distribution.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package forester.grass.procedural;

import com.jme3.material.Material;
import com.jme3.renderer.Camera;
import com.jme3.renderer.queue.RenderQueue.Bucket;
import com.jme3.scene.Geometry;
import com.jme3.scene.Node;
import com.jme3.terrain.Terrain;
import forester.grass.AbstractGrassLoader;
import forester.grass.GrassLayer;
import forester.grass.GrassPage;
import java.util.ArrayList;
import paging.AbstractLoadTask;
import paging.Page;
import paging.geometry.GeometryPage;
import paging.geometry.GeometryPage2D.PageBounds2D;
import paging.geometry.GeometryPagingEngine2D;

/**
 *
 * @author Andreas
 */
public class ProceduralGrassLoader extends AbstractGrassLoader {

    /**
     * The only constructor.
     * 
     * @param terrain The terrain used for getting height data.
     * @param rootNode The root node of the scene.
     * @param camera The camera used to render the scene.
     * @param pageSize The size of the geometry-pages.
     */
    public ProceduralGrassLoader(   Terrain terrain,
                                    Node rootNode,
                                    Camera camera,
                                    float pageSize
                                )
    {
        super(terrain,rootNode,camera,pageSize);
        this.pagingEngine = new GeometryPagingEngine2D(pageSize,farViewingDistance,rootNode,camera);
    }
    
    @Override
    public Runnable loadPage(Page page) {
        
        PageBounds2D bounds = ((GrassPage)page).getBounds();
        
        ArrayList<GrassLayer> tempList = new ArrayList(layers.size());
        //Find out which layers are within bounds.
        for(GrassLayer layer : layers){
            if(layer.isXzBounded()){
                if(layer.getMinX() > bounds.xMax || 
                   layer.getMaxX() < bounds.xMin ||
                   layer.getMinZ() > bounds.zMax || 
                   layer.getMaxZ() < bounds.zMin)
                {
                    continue;
                }
            }   
            tempList.add(layer);  
        }
        if(tempList.isEmpty()){
            return null;
        }
        LoadTask task = new LoadTask(page,tempList);
        return task;
    }

    protected class LoadTask extends AbstractLoadTask{

        ArrayList<GrassLayer> layerList;
        
        protected LoadTask(Page page, ArrayList<GrassLayer> layerList){
            super(page);
            this.layerList = layerList;
        }
        
        @Override
        public void run() {
            Node[] nodes = new Node[2];
            nodes[0] = new Node("Near");
            nodes[1] = new Node("Distant");
            PageBounds2D bounds = ((GrassPage)page).getBounds();
            
            for(GrassLayer layer: layerList)
            {   
                
                Geometry mainGeom = grassGen.createGrassGeometry(   layer,
                                                                bounds,
                                                                layer.getMeshType()
                                                            );
                Material mat = layer.getMaterial();
                mainGeom.setMaterial(mat);
                nodes[0].attachChild(mainGeom);
                nodes[0].setQueueBucket(Bucket.Transparent);
                Geometry impGeom = null;
                if(layer.getMeshType() == MeshType.QUADS){
                    impGeom = mainGeom.clone(false);
                }else{
                    impGeom = grassGen.createGrassGeometry( layer,
                                                            bounds,
                                                            MeshType.QUADS
                                                          );
                }
                impGeom.setMaterial(layer.getImpostorMaterial());
                nodes[1].attachChild(impGeom);
                nodes[1].setQueueBucket(Bucket.Transparent);
            }
        ((GeometryPage)page).setNodes(nodes);
        layerList = null;
        }
        
    }
}
