/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package forester.grass.procedural.algorithms;

import forester.grass.GrassLayer;
import forester.image.DensityMap;
import paging.geometry.GeometryPage2D.PageBounds2D;

/**
 *
 * @author Andreas
 */
public interface PlantingAlgorithm {
    /**
     * This should be an algorithm for generating grass. It should always
     * return the amount of grass patches that was generated.
     * 
     * @param bounds The page bounds.
     * @param grassData The array for storing grass data.
     * @param grassCount The initial number of grass patches.
     * @param densityMap A density map (or null).
     * @return The number of grass patches after running the algorithm.
     */
    public int generateGrassData(   PageBounds2D bounds,
                                    GrassLayer layer,
                                    float[] grassData, 
                                    int grassCount, 
                                    DensityMap densityMap
                                );
}
