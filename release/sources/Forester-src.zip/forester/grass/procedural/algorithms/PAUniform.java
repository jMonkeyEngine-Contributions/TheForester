/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package forester.grass.procedural.algorithms;

import com.jme3.math.FastMath;
import forester.grass.GrassLayer;
import forester.image.DensityMap;
import forester.util.FastRandom;
import paging.geometry.GeometryPage2D.PageBounds2D;

/**
 * The default planting algorithm. It supports densitymaps
 * @author Andreas
 */
public class PAUniform implements PlantingAlgorithm{
    
    @Override
    public int generateGrassData(   PageBounds2D bounds,
                                    GrassLayer layer,
                                    float[] grassData, 
                                    int grassCount, 
                                    DensityMap densityMap
                                )
    {
        boolean useDensityMap = false;
        
        if(densityMap != null){
            useDensityMap = true;
        }
        
        //Populating the array of locations (and also getting the total amount
        //of quads).
        FastRandom rand = new FastRandom();
        
        //Iterator
        int iIt = 0;
        
        if(useDensityMap){
            for(int i = 0; i < grassCount; i++)
            {
                
                float x = bounds.xMin + rand.unitRandom()*bounds.width;
                float z = bounds.zMin + rand.unitRandom()*bounds.height;
                                
                if(rand.unitRandom() < densityMap.getDensityUnfiltered(x, z))
                {
                    grassData[iIt++] = x;
                    grassData[iIt++] = z;
                    grassData[iIt++] = rand.unitRandom();
                    grassData[iIt++] = rand.unitRandom()*FastMath.TWO_PI;
                }
            
            }
        //if procedural
        } else {
            for(int i = 0; i < grassCount; i++)
            {
                float x = bounds.xMin + rand.unitRandom()*bounds.width;
                float z = bounds.zMin + rand.unitRandom()*bounds.height;
                
                if(layer.isXzBounded()){
                    float temp = x + bounds.center.x;
                    if(temp < layer.getMinX() || temp > layer.getMaxX()){
                        continue;
                    }
                    temp = z + bounds.center.z;
                    if(temp < layer.getMinZ() || temp > layer.getMaxZ()){
                        continue;
                    }
                }
                
                grassData[iIt++] = x;
                grassData[iIt++] = z;
                grassData[iIt++] = rand.unitRandom(); 
                grassData[iIt++] = rand.unitRandom()*FastMath.TWO_PI;
            }
        }
        //The iterator divided by four is the quad-count.
        return iIt/4;
    }
}
