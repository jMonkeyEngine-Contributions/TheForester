/*
 * Copyright (c) 2011, Andreas Olofsson
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * Redistributions of source code must retain the above copyright notice, 
 * this list of conditions and the following disclaimer.
 * 
 * Redistributions in binary form must reproduce the above copyright notice, 
 * this list of conditions and the following disclaimer in the documentation 
 * and/or other materials provided with the distribution.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package forester;

import paging.PageLoader;
import com.jme3.renderer.Camera;
import com.jme3.scene.Node;
import com.jme3.terrain.Terrain;
import forester.grass.GrassGrid;
import forester.grass.procedural.ProceduralGrassLoader;
import java.util.ArrayList;

/**
 * This class is used to create and maintain pageloaders.
 * 
 * @author Andreas
 */
public class Forester
{
    private Node rootNode;
    private Camera camera;
    private Terrain terrain;
    
    private ArrayList<PageLoader> list;
    
    /**
     * Creates a new Forester object.
     * 
     * @param rootNode The rootNode of the scene.
     * @param camera The camera.
     * @param terrain A terrain object.
     */
    public Forester(Node rootNode, Camera camera, Terrain terrain)
    {
        this.rootNode = rootNode;
        this.camera = camera;
        this.terrain = terrain;
        list = new ArrayList<PageLoader>();
    }
    
    /**
     * The update method. Call this method every frame to update the pageloaders.
     * 
     * @param tpf Time passed since the last update (in seconds).
     */
    public void update(float tpf)
    {
        for(PageLoader loader: list){
            loader.update(tpf);
        }
    }
    
    /**
     * A method for creating grass grids.
     * 
     * @param farViewingDistance The far viewing distance of the grass.
     * @param fadingDistance The distance where fading between different levels
     * of detail starts.
     * @param fadingRange The distance over which fading takes place.
     * @param geometryPageSize The size of geometry pages (note this value 
     * will be modified slightly to align the pages with the densitymaps).
     * @param mapSize The size of density maps.
     * @param useColorMaps Whether or not to enable colormaps (those has to be provided).
     * @return A reference to the GrassGrid object.
     */
    public GrassGrid createGrassGrid(   float farViewingDistance,
                                        float fadingDistance,
                                        float fadingRange,
                                        float geometryPageSize,
                                        int mapSize,
                                        boolean useColorMaps
                                    )
    {
        GrassGrid grassGrid = new GrassGrid(    terrain,
                                                rootNode,
                                                camera,
                                                geometryPageSize,
                                                mapSize,
                                                useColorMaps
                                            );
        grassGrid.setFarViewingDistance(farViewingDistance);
        grassGrid.setFadingDistance(fadingDistance);
        grassGrid.setFadingRange(fadingRange);
        list.add(grassGrid);
        return grassGrid;
    }
    
    /**
     * A method to create grass grids with default fading distance, fading range 
     * and page-size.
     * 
     * @param farViewingDistance The far viewing distance of the grass.
     * @param mapSize The size of density maps.
     * @param useColorMaps Whether or not to enable colormaps (those has to be provided).
     * @return A reference to the GrassGrid object.
     */
    public GrassGrid createGrassGrid(   float farViewingDistance,
                                        int mapSize,
                                        boolean useColorMaps
                                    )
    {
       return createGrassGrid(farViewingDistance,farViewingDistance*0.5f,farViewingDistance*0.1f,
               64f,mapSize,useColorMaps);
    }
    
    /**
     * A method for creating procedural grass.
     * 
     * @param farViewingDistance The far viewing distance of the grass.
     * @param fadingDistance The distance where fading between different levels
     * of detail starts.
     * @param fadingRange The distance over which fading takes place.
     * @param geometryPageSize The size of geometry pages (note this value 
     * @return A reference to the ProceduralGrassLoader object.
     */
    public ProceduralGrassLoader createProceduralGrass( float farViewingDistance,
                                                        float fadingDistance,
                                                        float fadingRange,
                                                        float geometryPageSize
                                                      )
    {
        ProceduralGrassLoader grassLoader = new ProceduralGrassLoader(terrain,rootNode,camera,geometryPageSize);
        grassLoader.setFarViewingDistance(farViewingDistance);
        grassLoader.setFadingDistance(fadingDistance);
        grassLoader.setFadingRange(fadingRange);
        list.add(grassLoader);
        return grassLoader;
    }
    
    /**
     * A method for creating procedural grass. Uses default values for
     * fadingDistance, fadingRange and geometryPageSize.
     * 
     * @param farViewingDistance The far viewing distance of the grass.
     * @return A reference to the ProceduralGrassLoader object.
     */
    public ProceduralGrassLoader createProceduralGrass(float farViewingDistance)
    {
        return createProceduralGrass(farViewingDistance,farViewingDistance*0.5f,farViewingDistance*0.1f, 64f);
    }

} //Forester
